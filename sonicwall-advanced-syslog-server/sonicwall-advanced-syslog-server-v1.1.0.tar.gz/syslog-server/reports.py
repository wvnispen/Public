"""
Report Engine
Generates security, traffic, compliance, and operational reports
from parsed firewall events in the fw_events table.
"""

from datetime import datetime, timedelta


def get_time_filter(period="24h"):
    """Convert period string to SQL interval and label."""
    mapping = {
        "1h":   ("1 HOUR",   "Last Hour"),
        "6h":   ("6 HOUR",   "Last 6 Hours"),
        "12h":  ("12 HOUR",  "Last 12 Hours"),
        "24h":  ("24 HOUR",  "Last 24 Hours"),
        "7d":   ("7 DAY",    "Last 7 Days"),
        "30d":  ("30 DAY",   "Last 30 Days"),
        "90d":  ("90 DAY",   "Last 90 Days"),
    }
    return mapping.get(period, mapping["24h"])


def run_report(cursor, report_type, period="24h", limit=50, extra_params=None):
    """
    Run a named report and return results.

    Args:
        cursor: Database cursor (dictionary=True)
        report_type: The report identifier string
        period: Time window (1h, 6h, 12h, 24h, 7d, 30d, 90d)
        limit: Max rows to return
        extra_params: Dict of additional filter params

    Returns:
        dict with 'title', 'description', 'columns', 'rows', 'chart_type', 'period_label'
    """
    interval, period_label = get_time_filter(period)
    time_clause = f"received_at >= NOW() - INTERVAL {interval}"
    extra = extra_params or {}

    reports = {
        # ═══════════════════════════════════════════════════════════════════
        # SECURITY & THREAT REPORTS
        # ═══════════════════════════════════════════════════════════════════

        "top_denied_hosts": {
            "title": "Top Denied Hosts / IPs",
            "description": "External or internal hosts most frequently blocked by firewall rules",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT src_ip, src_zone,
                       COUNT(*) as deny_count,
                       COUNT(DISTINCT dst_ip) as unique_targets,
                       GROUP_CONCAT(DISTINCT dst_port ORDER BY dst_port SEPARATOR ', ') as target_ports
                FROM fw_events
                WHERE {time_clause} AND event_type = 'denied'
                GROUP BY src_ip, src_zone
                ORDER BY deny_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Source IP", "Zone", "Deny Count", "Unique Targets", "Target Ports"],
        },

        "top_denied_destinations": {
            "title": "Top Denied Destinations",
            "description": "Most frequently blocked destination IPs — may indicate attempted data exfiltration or C2",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT dst_ip, dst_name,
                       COUNT(*) as deny_count,
                       COUNT(DISTINCT src_ip) as unique_sources,
                       GROUP_CONCAT(DISTINCT protocol_app ORDER BY protocol_app SEPARATOR ', ') as protocols
                FROM fw_events
                WHERE {time_clause} AND event_type = 'denied'
                GROUP BY dst_ip, dst_name
                ORDER BY deny_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Destination IP", "Hostname", "Deny Count", "Unique Sources", "Protocols"],
        },

        "top_permitted_apps": {
            "title": "Top Permitted Traffic by Application",
            "description": "Applications passing through the firewall — useful for shadow IT detection",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT
                    COALESCE(protocol_app, protocol, 'unknown') as application,
                    COUNT(*) as event_count,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes,
                    COUNT(DISTINCT src_ip) as unique_sources
                FROM fw_events
                WHERE {time_clause} AND event_type = 'traffic'
                  AND fw_action != 'drop'
                GROUP BY application
                ORDER BY event_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Application", "Event Count", "Total Bytes", "Unique Sources"],
        },

        "threats_attacks": {
            "title": "Security Threats & Attacks",
            "description": "IPS alerts, virus detections, port scans, and protocol anomalies",
            "chart_type": "table",
            "sql": f"""
                SELECT received_at, src_ip, src_zone, dst_ip, dst_port,
                       event_message, ips_category, ips_priority,
                       protocol_app, fw_action
                FROM fw_events
                WHERE {time_clause} AND event_type = 'threat'
                ORDER BY received_at DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Time", "Source IP", "Zone", "Dest IP", "Dest Port",
                        "Message", "IPS Category", "Priority", "Protocol", "Action"],
        },

        "threat_summary": {
            "title": "Threat Summary by Category",
            "description": "Aggregated view of threats grouped by IPS category",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT
                    COALESCE(ips_category, event_message, 'Unknown') as threat_category,
                    COUNT(*) as event_count,
                    COUNT(DISTINCT src_ip) as unique_sources,
                    COUNT(DISTINCT dst_ip) as unique_targets,
                    MIN(received_at) as first_seen,
                    MAX(received_at) as last_seen
                FROM fw_events
                WHERE {time_clause} AND event_type = 'threat'
                GROUP BY threat_category
                ORDER BY event_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Threat Category", "Count", "Unique Sources", "Unique Targets",
                        "First Seen", "Last Seen"],
        },

        "failed_auth": {
            "title": "Failed Authentication Attempts",
            "description": "Failed VPN and admin logins — often indicates brute-force attacks",
            "chart_type": "table",
            "sql": f"""
                SELECT received_at, src_ip, vpn_user, event_message,
                       message_id, vpn_portal, vpn_domain
                FROM fw_events
                WHERE {time_clause}
                  AND event_type IN ('auth', 'admin')
                  AND (message_id IN (25, 30, 32, 33, 506)
                       OR event_message LIKE '%%denied%%'
                       OR event_message LIKE '%%failed%%'
                       OR event_message LIKE '%%bad credentials%%')
                ORDER BY received_at DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Time", "Source IP", "User", "Message",
                        "Msg ID", "Portal", "Domain"],
        },

        "failed_auth_by_ip": {
            "title": "Failed Auth Attempts by Source IP",
            "description": "IPs with the most failed login attempts — top brute-force candidates",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT src_ip,
                       COUNT(*) as fail_count,
                       COUNT(DISTINCT vpn_user) as users_tried,
                       GROUP_CONCAT(DISTINCT vpn_user ORDER BY vpn_user SEPARATOR ', ') as usernames,
                       MIN(received_at) as first_attempt,
                       MAX(received_at) as last_attempt
                FROM fw_events
                WHERE {time_clause}
                  AND event_type IN ('auth', 'admin')
                  AND (message_id IN (25, 30, 32, 33, 506)
                       OR event_message LIKE '%%denied%%'
                       OR event_message LIKE '%%failed%%')
                GROUP BY src_ip
                ORDER BY fail_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Source IP", "Failed Attempts", "Users Tried", "Usernames",
                        "First Attempt", "Last Attempt"],
        },

        "top_infected_hosts": {
            "title": "Top Potentially Infected Hosts",
            "description": "Internal IPs triggering the most IPS/threat alerts",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT src_ip, src_zone,
                       COUNT(*) as threat_count,
                       COUNT(DISTINCT dst_ip) as unique_targets,
                       COUNT(DISTINCT ips_category) as threat_types,
                       GROUP_CONCAT(DISTINCT ips_category SEPARATOR ', ') as categories
                FROM fw_events
                WHERE {time_clause} AND event_type = 'threat'
                  AND src_zone IS NOT NULL
                GROUP BY src_ip, src_zone
                ORDER BY threat_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Source IP", "Zone", "Threat Count", "Unique Targets",
                        "Threat Types", "Categories"],
        },

        # ═══════════════════════════════════════════════════════════════════
        # TRAFFIC & BANDWIDTH REPORTS
        # ═══════════════════════════════════════════════════════════════════

        "top_talkers": {
            "title": "Top Talkers / Bandwidth Usage",
            "description": "Internal IPs consuming the most bandwidth",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT src_ip,
                       SUM(bytes_sent) as total_sent,
                       SUM(bytes_rcvd) as total_rcvd,
                       SUM(bytes_sent + bytes_rcvd) as total_bytes,
                       COUNT(*) as session_count,
                       COUNT(DISTINCT dst_ip) as unique_destinations
                FROM fw_events
                WHERE {time_clause} AND event_type = 'traffic'
                GROUP BY src_ip
                ORDER BY total_bytes DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Source IP", "Bytes Sent", "Bytes Received",
                        "Total Bytes", "Sessions", "Unique Destinations"],
        },

        "inbound_outbound": {
            "title": "Inbound vs Outbound Traffic",
            "description": "Traffic flow by zone direction — useful for detecting data exfiltration",
            "chart_type": "bar",
            "sql": f"""
                SELECT
                    CONCAT(COALESCE(src_zone, 'Unknown'), ' → ', COALESCE(dst_zone, 'Unknown')) as flow,
                    COUNT(*) as event_count,
                    SUM(bytes_sent) as bytes_sent,
                    SUM(bytes_rcvd) as bytes_rcvd,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes
                FROM fw_events
                WHERE {time_clause} AND event_type = 'traffic'
                  AND src_zone IS NOT NULL
                GROUP BY flow
                ORDER BY total_bytes DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Traffic Flow", "Events", "Bytes Sent", "Bytes Received", "Total Bytes"],
        },

        "top_protocols": {
            "title": "Top Protocols & Services",
            "description": "Primary protocols being used on the network",
            "chart_type": "doughnut",
            "sql": f"""
                SELECT
                    COALESCE(protocol, 'unknown') as transport,
                    COALESCE(protocol_app, 'unknown') as application,
                    COUNT(*) as event_count,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes
                FROM fw_events
                WHERE {time_clause}
                GROUP BY transport, application
                ORDER BY event_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Transport", "Application", "Event Count", "Total Bytes"],
        },

        "vpn_activity": {
            "title": "VPN Activity Report",
            "description": "Active VPN users, login/logout events, and bandwidth usage",
            "chart_type": "table",
            "sql": f"""
                SELECT vpn_user,
                       COUNT(*) as event_count,
                       SUM(CASE WHEN message_id IN (24, 31, 546) THEN 1 ELSE 0 END) as logins,
                       SUM(CASE WHEN message_id IN (25, 32, 33) THEN 1 ELSE 0 END) as failed_logins,
                       SUM(bytes_sent) as bytes_sent,
                       SUM(bytes_rcvd) as bytes_rcvd,
                       MIN(received_at) as first_seen,
                       MAX(received_at) as last_seen,
                       GROUP_CONCAT(DISTINCT src_ip ORDER BY src_ip SEPARATOR ', ') as source_ips
                FROM fw_events
                WHERE {time_clause} AND event_type IN ('vpn', 'auth')
                  AND vpn_user IS NOT NULL AND vpn_user != ''
                GROUP BY vpn_user
                ORDER BY event_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["User", "Events", "Logins", "Failed", "Bytes Sent",
                        "Bytes Rcvd", "First Seen", "Last Seen", "Source IPs"],
        },

        "traffic_hourly": {
            "title": "Hourly Traffic Volume",
            "description": "Traffic volume broken down by hour",
            "chart_type": "line",
            "sql": f"""
                SELECT
                    DATE_FORMAT(received_at, '%%Y-%%m-%%d %%H:00') as hour_bucket,
                    COUNT(*) as event_count,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes,
                    SUM(CASE WHEN event_type = 'denied' THEN 1 ELSE 0 END) as denied_count,
                    SUM(CASE WHEN event_type = 'threat' THEN 1 ELSE 0 END) as threat_count
                FROM fw_events
                WHERE {time_clause}
                GROUP BY hour_bucket
                ORDER BY hour_bucket
            """,
            "params": [],
            "columns": ["Hour", "Events", "Total Bytes", "Denied", "Threats"],
        },

        # ═══════════════════════════════════════════════════════════════════
        # POLICY & RULE MANAGEMENT
        # ═══════════════════════════════════════════════════════════════════

        "rule_utilization": {
            "title": "Firewall Rule Utilization",
            "description": "Identifies most and least used firewall rules",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT
                    COALESCE(rule_name, '(no rule)') as rule_name,
                    COUNT(*) as hit_count,
                    SUM(CASE WHEN event_type = 'denied' THEN 1 ELSE 0 END) as denied,
                    SUM(CASE WHEN event_type = 'traffic' THEN 1 ELSE 0 END) as allowed,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes,
                    COUNT(DISTINCT src_ip) as unique_sources
                FROM fw_events
                WHERE {time_clause} AND rule_name IS NOT NULL
                GROUP BY rule_name
                ORDER BY hit_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Rule Name", "Hit Count", "Denied", "Allowed",
                        "Total Bytes", "Unique Sources"],
        },

        "config_changes": {
            "title": "Configuration Change Log",
            "description": "Tracks firewall rule and configuration changes — who, what, when",
            "chart_type": "table",
            "sql": f"""
                SELECT received_at, src_ip, vpn_user, event_message,
                       message_id, note
                FROM fw_events
                WHERE {time_clause} AND event_type = 'admin'
                ORDER BY received_at DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Time", "Source IP", "Admin User", "Message", "Msg ID", "Note"],
        },

        # ═══════════════════════════════════════════════════════════════════
        # COMPLIANCE & AUDIT
        # ═══════════════════════════════════════════════════════════════════

        "url_filtering": {
            "title": "URL / Web Filtering Report",
            "description": "User access to website categories (social, gambling, malicious, etc.)",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT
                    COALESCE(url_category, 'Uncategorized') as category,
                    COUNT(*) as hit_count,
                    COUNT(DISTINCT src_ip) as unique_users,
                    COUNT(DISTINCT url_dstname) as unique_sites,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes
                FROM fw_events
                WHERE {time_clause} AND event_type = 'web'
                  AND url_category IS NOT NULL
                GROUP BY category
                ORDER BY hit_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Category", "Hits", "Unique Users", "Unique Sites", "Total Bytes"],
        },

        "top_websites": {
            "title": "Top Websites Accessed",
            "description": "Most frequently accessed destination hostnames",
            "chart_type": "bar_horizontal",
            "sql": f"""
                SELECT
                    COALESCE(url_dstname, dst_name, dst_ip) as website,
                    url_category,
                    COUNT(*) as hit_count,
                    COUNT(DISTINCT src_ip) as unique_users,
                    SUM(bytes_sent + bytes_rcvd) as total_bytes
                FROM fw_events
                WHERE {time_clause}
                  AND (url_dstname IS NOT NULL OR dst_name IS NOT NULL)
                  AND event_type IN ('web', 'traffic')
                GROUP BY website, url_category
                ORDER BY hit_count DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Website", "Category", "Hits", "Unique Users", "Total Bytes"],
        },

        "admin_activity": {
            "title": "Admin Activity Report",
            "description": "All administrator actions on the firewall management console",
            "chart_type": "table",
            "sql": f"""
                SELECT received_at, src_ip, vpn_user,
                       event_message, message_id, fw_action, note
                FROM fw_events
                WHERE {time_clause}
                  AND (event_type = 'admin'
                       OR message_id IN (29, 30, 506, 520, 521, 522, 548, 860))
                ORDER BY received_at DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Time", "Source IP", "Admin", "Message", "Msg ID", "Action", "Note"],
        },

        "event_type_summary": {
            "title": "Event Type Summary",
            "description": "Overview of all event types for compliance dashboards",
            "chart_type": "doughnut",
            "sql": f"""
                SELECT event_type,
                       COUNT(*) as event_count,
                       COUNT(DISTINCT src_ip) as unique_sources,
                       COUNT(DISTINCT dst_ip) as unique_destinations
                FROM fw_events
                WHERE {time_clause}
                GROUP BY event_type
                ORDER BY event_count DESC
            """,
            "params": [],
            "columns": ["Event Type", "Count", "Unique Sources", "Unique Destinations"],
        },

        "geo_blocks": {
            "title": "Geo-IP & Botnet Blocks",
            "description": "Connections blocked by Geo-IP or Botnet filtering",
            "chart_type": "table",
            "sql": f"""
                SELECT received_at, src_ip, dst_ip, dst_port,
                       event_message, protocol_app, fw_action, note
                FROM fw_events
                WHERE {time_clause}
                  AND message_id IN (882, 884)
                ORDER BY received_at DESC
                LIMIT %s
            """,
            "params": [limit],
            "columns": ["Time", "Source IP", "Dest IP", "Dest Port",
                        "Message", "Protocol", "Action", "Note"],
        },
    }

    if report_type not in reports:
        return None

    report = reports[report_type]
    cursor.execute(report["sql"], report["params"])
    rows = cursor.fetchall()

    return {
        "type": report_type,
        "title": report["title"],
        "description": report["description"],
        "columns": report["columns"],
        "rows": rows,
        "chart_type": report["chart_type"],
        "period": period,
        "period_label": period_label,
        "generated_at": datetime.utcnow(),
        "row_count": len(rows),
    }


# ─── Report catalog for the UI ──────────────────────────────────────────────

REPORT_CATALOG = [
    {
        "group": "Security & Threats",
        "icon": "shield-halved",
        "reports": [
            {"id": "top_denied_hosts", "name": "Top Denied Hosts/IPs", "icon": "ban"},
            {"id": "top_denied_destinations", "name": "Top Denied Destinations", "icon": "circle-xmark"},
            {"id": "top_permitted_apps", "name": "Top Permitted Applications", "icon": "list-check"},
            {"id": "threats_attacks", "name": "Security Threats & Attacks", "icon": "bug"},
            {"id": "threat_summary", "name": "Threat Summary by Category", "icon": "chart-bar"},
            {"id": "failed_auth", "name": "Failed Authentication Attempts", "icon": "key"},
            {"id": "failed_auth_by_ip", "name": "Failed Auth by Source IP", "icon": "user-xmark"},
            {"id": "top_infected_hosts", "name": "Top Potentially Infected Hosts", "icon": "virus"},
        ],
    },
    {
        "group": "Traffic & Bandwidth",
        "icon": "network-wired",
        "reports": [
            {"id": "top_talkers", "name": "Top Talkers / Bandwidth", "icon": "gauge-high"},
            {"id": "inbound_outbound", "name": "Inbound vs Outbound Traffic", "icon": "right-left"},
            {"id": "top_protocols", "name": "Top Protocols & Services", "icon": "diagram-project"},
            {"id": "vpn_activity", "name": "VPN Activity Report", "icon": "lock"},
            {"id": "traffic_hourly", "name": "Hourly Traffic Volume", "icon": "chart-line"},
        ],
    },
    {
        "group": "Policy & Rules",
        "icon": "clipboard-list",
        "reports": [
            {"id": "rule_utilization", "name": "Firewall Rule Utilization", "icon": "filter"},
            {"id": "config_changes", "name": "Configuration Change Log", "icon": "pen-to-square"},
        ],
    },
    {
        "group": "Compliance & Audit",
        "icon": "file-shield",
        "reports": [
            {"id": "url_filtering", "name": "URL / Web Filtering", "icon": "globe"},
            {"id": "top_websites", "name": "Top Websites Accessed", "icon": "earth-americas"},
            {"id": "admin_activity", "name": "Admin Activity Report", "icon": "user-shield"},
            {"id": "event_type_summary", "name": "Event Type Summary", "icon": "chart-pie"},
            {"id": "geo_blocks", "name": "Geo-IP & Botnet Blocks", "icon": "map-location-dot"},
        ],
    },
]
