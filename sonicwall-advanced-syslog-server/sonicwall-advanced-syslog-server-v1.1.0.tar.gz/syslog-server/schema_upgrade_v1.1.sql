-- ============================================================================
-- Sonicwall Syslog Server v1.1.0 — Schema Upgrade
-- Adds parsed firewall fields and reporting views
-- Run AFTER the base schema.sql has been applied
-- ============================================================================

USE syslog_db;

-- ─── Parsed firewall events table ──────────────────────────────────────────
-- Stores structured fields extracted from SonicWall (and other) firewall logs.
-- One row per firewall event, linked back to the raw syslog_entries row.

CREATE TABLE IF NOT EXISTS fw_events (
    id              BIGINT UNSIGNED AUTO_INCREMENT,
    syslog_id       BIGINT UNSIGNED     DEFAULT NULL,
    received_at     DATETIME(3)         NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    source_ip       VARCHAR(45)         NOT NULL,

    -- SonicWall header fields
    fw_id           VARCHAR(64)         DEFAULT NULL,       -- id= (firewall, sslvpn, etc)
    serial_number   VARCHAR(32)         DEFAULT NULL,       -- sn=
    fw_ip           VARCHAR(45)         DEFAULT NULL,       -- fw=
    fw_priority     TINYINT UNSIGNED    DEFAULT NULL,       -- pri=
    category_id     INT UNSIGNED        DEFAULT NULL,       -- c=
    message_id      INT UNSIGNED        DEFAULT NULL,       -- m=
    event_message   VARCHAR(512)        DEFAULT NULL,       -- msg=
    event_count     INT UNSIGNED        DEFAULT 1,          -- n=

    -- Network fields
    src_ip          VARCHAR(45)         DEFAULT NULL,
    src_port        INT UNSIGNED        DEFAULT NULL,
    src_iface       VARCHAR(32)         DEFAULT NULL,       -- e.g. X0, X1
    src_name        VARCHAR(255)        DEFAULT NULL,       -- resolved hostname
    src_zone        VARCHAR(64)         DEFAULT NULL,       -- srcZone=
    src_mac         VARCHAR(20)         DEFAULT NULL,

    dst_ip          VARCHAR(45)         DEFAULT NULL,
    dst_port        INT UNSIGNED        DEFAULT NULL,
    dst_iface       VARCHAR(32)         DEFAULT NULL,
    dst_name        VARCHAR(255)        DEFAULT NULL,       -- dstname=
    dst_zone        VARCHAR(64)         DEFAULT NULL,       -- dstZone=
    dst_mac         VARCHAR(20)         DEFAULT NULL,

    nat_src         VARCHAR(64)         DEFAULT NULL,       -- natSrc=
    nat_dst         VARCHAR(64)         DEFAULT NULL,       -- natDst=

    -- Protocol / application
    protocol        VARCHAR(32)         DEFAULT NULL,       -- tcp, udp, icmp
    protocol_app    VARCHAR(64)         DEFAULT NULL,       -- http, https, dns, etc
    app_id          INT UNSIGNED        DEFAULT NULL,       -- app=
    app_cat         VARCHAR(128)        DEFAULT NULL,       -- appcat=
    app_name_full   VARCHAR(128)        DEFAULT NULL,       -- full app name if available

    -- Traffic metrics
    bytes_sent      BIGINT UNSIGNED     DEFAULT 0,          -- sent=
    bytes_rcvd      BIGINT UNSIGNED     DEFAULT 0,          -- rcvd=
    packets_sent    BIGINT UNSIGNED     DEFAULT 0,          -- spkt=
    packets_rcvd    BIGINT UNSIGNED     DEFAULT 0,          -- rpkt=

    -- Action / policy
    fw_action       VARCHAR(32)         DEFAULT NULL,       -- fw_action= (forward, drop, NA)
    af_action       VARCHAR(32)         DEFAULT NULL,       -- af_action=
    rule_name       VARCHAR(255)        DEFAULT NULL,       -- rule=
    sess_type       VARCHAR(64)         DEFAULT NULL,       -- sess=

    -- Security / IPS
    ips_sid         INT UNSIGNED        DEFAULT NULL,       -- sid=
    ips_category    VARCHAR(128)        DEFAULT NULL,       -- ipscat=
    ips_priority    TINYINT UNSIGNED    DEFAULT NULL,       -- ipspri=

    -- URL / web filtering
    url_category    VARCHAR(128)        DEFAULT NULL,       -- Category=
    url_code        INT UNSIGNED        DEFAULT NULL,       -- code=
    url_arg         TEXT                DEFAULT NULL,       -- arg=
    url_dstname     VARCHAR(255)        DEFAULT NULL,       -- dstname=

    -- VPN
    vpn_user        VARCHAR(128)        DEFAULT NULL,       -- user= or usr=
    vpn_portal      VARCHAR(128)        DEFAULT NULL,       -- portal=
    vpn_domain      VARCHAR(128)        DEFAULT NULL,       -- domain=

    -- Additional
    note            TEXT                DEFAULT NULL,       -- note=
    result_code     INT                 DEFAULT NULL,       -- result=
    dpi_flag        TINYINT             DEFAULT NULL,       -- dpi=

    -- Classification for reporting
    event_type      ENUM(
        'traffic',          -- Connection Opened/Closed, general traffic
        'denied',           -- Dropped / blocked connections
        'threat',           -- IPS alerts, attacks, virus
        'vpn',              -- VPN login/logout/activity
        'auth',             -- Authentication events
        'admin',            -- Admin login, config changes
        'system',           -- System events, HA, etc
        'web',              -- URL/web filtering hits
        'other'
    ) NOT NULL DEFAULT 'other',

    PRIMARY KEY (id, received_at),

    -- Performance indexes for reports
    INDEX idx_fw_received       (received_at),
    INDEX idx_fw_src_ip         (src_ip),
    INDEX idx_fw_dst_ip         (dst_ip),
    INDEX idx_fw_action         (fw_action),
    INDEX idx_fw_event_type     (event_type),
    INDEX idx_fw_event_type_ts  (event_type, received_at),
    INDEX idx_fw_protocol       (protocol, protocol_app),
    INDEX idx_fw_rule           (rule_name(191)),
    INDEX idx_fw_message_id     (message_id),
    INDEX idx_fw_vpn_user       (vpn_user(128)),
    INDEX idx_fw_url_category   (url_category(128)),
    INDEX idx_fw_ips_cat        (ips_category(128)),
    INDEX idx_fw_src_dst        (src_ip, dst_ip),
    INDEX idx_fw_bytes          (bytes_sent, bytes_rcvd),
    INDEX idx_fw_serial         (serial_number),
    INDEX idx_fw_syslog_id      (syslog_id),

    FULLTEXT INDEX ft_fw_message (event_message)

) ENGINE=InnoDB
  ROW_FORMAT=COMPRESSED
  PARTITION BY RANGE (TO_DAYS(received_at)) (
    PARTITION p_default VALUES LESS THAN MAXVALUE
);


-- ─── SonicWall message ID reference ────────────────────────────────────────
-- Maps SonicWall message IDs to human-readable event names

CREATE TABLE IF NOT EXISTS fw_message_ids (
    message_id      INT UNSIGNED PRIMARY KEY,
    event_name      VARCHAR(255)    NOT NULL,
    event_group     VARCHAR(64)     DEFAULT NULL,
    default_type    VARCHAR(20)     DEFAULT 'other'
) ENGINE=InnoDB;

-- Common SonicWall message IDs
INSERT IGNORE INTO fw_message_ids (message_id, event_name, event_group, default_type) VALUES
    (14,  'Web site access denied',        'Web Filter',    'web'),
    (16,  'Web site accessed',             'Web Filter',    'web'),
    (22,  'Attack detected',               'Security',      'threat'),
    (23,  'IP spoof detected',             'Security',      'threat'),
    (24,  'User login allowed',            'Auth',          'auth'),
    (25,  'User login denied',             'Auth',          'auth'),
    (26,  'Connection denied',             'Firewall',      'denied'),
    (27,  'Possible SYN flood',            'Security',      'threat'),
    (28,  'Ping of Death blocked',         'Security',      'threat'),
    (29,  'Admin login allowed',           'Admin',         'admin'),
    (30,  'Admin login denied',            'Admin',         'admin'),
    (31,  'User login from internal zone', 'Auth',          'auth'),
    (32,  'User login denied bad creds',   'Auth',          'auth'),
    (33,  'Unknown user login attempt',    'Auth',          'auth'),
    (36,  'TCP connection dropped',        'Firewall',      'denied'),
    (37,  'UDP packet dropped',            'Firewall',      'denied'),
    (38,  'Connection dropped',            'Firewall',      'denied'),
    (39,  'ICMP packet dropped',           'Firewall',      'denied'),
    (41,  'Unknown network access',        'Firewall',      'traffic'),
    (82,  'Possible port scan',            'Security',      'threat'),
    (83,  'Probable port scan detected',   'Security',      'threat'),
    (97,  'Web site hit',                  'Web Filter',    'web'),
    (98,  'Connection Opened',             'Firewall',      'traffic'),
    (175, 'IPS prevention alert',          'IPS',           'threat'),
    (260, 'IPS detection alert',           'IPS',           'threat'),
    (261, 'Anti-virus alert',              'Security',      'threat'),
    (401, 'VPN IKE proposal',              'VPN',           'vpn'),
    (402, 'VPN policy added',              'VPN',           'vpn'),
    (403, 'VPN tunnel established',        'VPN',           'vpn'),
    (404, 'VPN tunnel terminated',         'VPN',           'vpn'),
    (406, 'VPN SA deleted',                'VPN',           'vpn'),
    (411, 'VPN SPI mismatch',              'VPN',           'vpn'),
    (413, 'VPN IKE negotiation error',     'VPN',           'vpn'),
    (428, 'VPN IKE proposal mismatch',     'VPN',           'vpn'),
    (440, 'VPN connection opened',         'VPN',           'vpn'),
    (441, 'VPN connection closed',         'VPN',           'vpn'),
    (461, 'DHCP lease',                    'System',        'system'),
    (501, 'Ping of Death dropped',         'Security',      'threat'),
    (502, 'IP spoof dropped',              'Security',      'threat'),
    (503, 'SYN flood possible',            'Security',      'threat'),
    (505, 'Land attack dropped',           'Security',      'threat'),
    (506, 'Admin login disabled',          'Admin',         'admin'),
    (520, 'Rule added',                    'Admin',         'admin'),
    (521, 'Rule deleted',                  'Admin',         'admin'),
    (522, 'Rule modified',                 'Admin',         'admin'),
    (537, 'Connection Closed',             'Firewall',      'traffic'),
    (538, 'TCP connection dropped',        'Firewall',      'denied'),
    (546, 'User login via SSLVPN',         'VPN',           'vpn'),
    (547, 'User logout from SSLVPN',       'VPN',           'vpn'),
    (548, 'Admin audit event',             'Admin',         'admin'),
    (598, 'HA failover',                   'System',        'system'),
    (608, 'IPS detection alert',           'IPS',           'threat'),
    (860, 'Configuration changed',         'Admin',         'admin'),
    (882, 'Geo-IP blocked',               'Security',      'denied'),
    (884, 'Botnet blocked',               'Security',      'denied'),
    (1154,'Capture ATP alert',             'Security',      'threat'),
    (1369,'Anti-spam',                     'Security',      'threat');


-- ─── Saved report configurations ──────────────────────────────────────────

CREATE TABLE IF NOT EXISTS saved_reports (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255)    NOT NULL,
    report_type     VARCHAR(64)     NOT NULL,
    parameters      JSON            DEFAULT NULL,
    schedule        VARCHAR(32)     DEFAULT NULL,       -- daily, weekly, monthly, none
    created_by      INT UNSIGNED    DEFAULT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_run        DATETIME        DEFAULT NULL
) ENGINE=InnoDB;


-- ─── Alert rules ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS alert_rules (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255)    NOT NULL,
    enabled         TINYINT(1)      NOT NULL DEFAULT 1,
    condition_type  VARCHAR(64)     NOT NULL,       -- threshold, pattern, etc
    condition_json  JSON            NOT NULL,
    severity        VARCHAR(20)     NOT NULL DEFAULT 'warning',
    notify_method   VARCHAR(32)     DEFAULT 'dashboard',  -- dashboard, email
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_triggered  DATETIME        DEFAULT NULL,
    trigger_count   INT UNSIGNED    DEFAULT 0
) ENGINE=InnoDB;


-- ─── Triggered alerts log ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS alert_log (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rule_id         INT UNSIGNED    NOT NULL,
    triggered_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    details         TEXT            DEFAULT NULL,
    acknowledged    TINYINT(1)      NOT NULL DEFAULT 0,
    acknowledged_by VARCHAR(80)     DEFAULT NULL,
    acknowledged_at DATETIME        DEFAULT NULL,

    INDEX idx_alert_time (triggered_at),
    INDEX idx_alert_rule (rule_id),
    INDEX idx_alert_ack  (acknowledged)
) ENGINE=InnoDB;


-- ─── Insert default alert rules ───────────────────────────────────────────

INSERT IGNORE INTO alert_rules (id, name, condition_type, condition_json, severity) VALUES
    (1, 'High volume of denied connections',
        'threshold',
        '{"event_type": "denied", "threshold": 1000, "window_minutes": 5}',
        'warning'),
    (2, 'Port scan detected',
        'message_id',
        '{"message_ids": [82, 83], "threshold": 1, "window_minutes": 1}',
        'critical'),
    (3, 'Failed admin login attempts',
        'message_id',
        '{"message_ids": [30, 506], "threshold": 3, "window_minutes": 10}',
        'critical'),
    (4, 'Failed VPN login attempts',
        'message_id',
        '{"message_ids": [25, 32, 33], "threshold": 5, "window_minutes": 10}',
        'warning'),
    (5, 'IPS threat detected',
        'event_type',
        '{"event_type": "threat", "threshold": 1, "window_minutes": 1}',
        'critical'),
    (6, 'Configuration change',
        'message_id',
        '{"message_ids": [520, 521, 522, 860], "threshold": 1, "window_minutes": 1}',
        'info');
