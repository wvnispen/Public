---
name: Bug Report
about: Report a bug to help us improve
title: "[BUG] "
labels: bug
assignees: ''
---

## Describe the Bug
A clear and concise description of what the bug is.

## Environment
- **OS**: (e.g., Ubuntu 24.04 LTS)
- **Python version**: (e.g., 3.12.3)
- **MariaDB version**: (e.g., 10.11.6)
- **Sonicwall Advanced Syslog Server version**: (e.g., 1.1.0)
- **Browser** (if web UI related): (e.g., Chrome 122)

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
A clear description of what you expected to happen.

## Actual Behavior
A clear description of what actually happened.

## Logs
```
Paste relevant logs here from:
  sudo journalctl -u syslog-receiver -n 50 --no-pager
  sudo journalctl -u syslog-web -n 50 --no-pager
```

## Screenshots
If applicable, add screenshots to help explain the problem.

## Additional Context
Add any other context about the problem here.
