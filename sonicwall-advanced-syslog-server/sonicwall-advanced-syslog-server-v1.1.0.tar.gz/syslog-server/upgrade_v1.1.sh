#!/usr/bin/env bash
# ============================================================================
# Sonicwall Syslog Server — Upgrade from v1.0.x to v1.1.0
# Adds: Firewall analytics, reports, alerts
# ============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

INSTALL_DIR="/opt/syslog-server"
CONFIG_DIR="/etc/syslog-server"
SERVICE_USER="syslog-server"

echo -e "${CYAN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║   Sonicwall Syslog Server — Upgrade to v1.1  ║"
echo "  ║   Adding: Reports, Alerts, FW Analytics       ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Error: Run as root (sudo).${NC}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Get DB credentials ────────────────────────────────────────────────────

read -sp "MariaDB root password: " MYSQL_ROOT_PASS
echo ""

# Read DB name from existing config
DB_NAME="syslog_db"
if [[ -f "${CONFIG_DIR}/config.json" ]]; then
    DB_NAME=$(python3 -c "import json; print(json.load(open('${CONFIG_DIR}/config.json')).get('db_name','syslog_db'))" 2>/dev/null || echo "syslog_db")
fi

echo -e "\n${CYAN}[1/4] Applying database schema upgrade...${NC}"

mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} < "${SCRIPT_DIR}/schema_upgrade_v1.1.sql"

echo -e "${GREEN}  ✓ Database upgraded (fw_events, alert_rules, etc.)${NC}"

# ─── Update application files ──────────────────────────────────────────────

echo -e "\n${CYAN}[2/4] Updating application files...${NC}"

# Stop services
systemctl stop syslog-receiver syslog-web 2>/dev/null || true

# Copy new and updated files
cp "${SCRIPT_DIR}/syslog_receiver.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/web_app.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/fw_parser.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/reports.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/requirements.txt" "${INSTALL_DIR}/"
cp -r "${SCRIPT_DIR}/templates" "${INSTALL_DIR}/"

if [[ -d "${SCRIPT_DIR}/static" ]]; then
    cp -r "${SCRIPT_DIR}/static" "${INSTALL_DIR}/"
fi

# Fix ownership
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"

echo -e "${GREEN}  ✓ Application files updated${NC}"

# ─── Update Python dependencies ────────────────────────────────────────────

echo -e "\n${CYAN}[3/4] Updating Python packages...${NC}"

"${INSTALL_DIR}/venv/bin/pip" install --quiet --upgrade pip
"${INSTALL_DIR}/venv/bin/pip" install --quiet -r "${INSTALL_DIR}/requirements.txt"

echo -e "${GREEN}  ✓ Python packages updated${NC}"

# ─── Restart services ──────────────────────────────────────────────────────

echo -e "\n${CYAN}[4/4] Restarting services...${NC}"

systemctl start syslog-receiver
systemctl start syslog-web

sleep 2

if systemctl is-active --quiet syslog-receiver && systemctl is-active --quiet syslog-web; then
    echo -e "${GREEN}  ✓ Services restarted successfully${NC}"
else
    echo -e "${YELLOW}  ⚠ One or more services may not have started. Check:${NC}"
    echo "    sudo journalctl -u syslog-receiver -n 20 --no-pager"
    echo "    sudo journalctl -u syslog-web -n 20 --no-pager"
fi

# ─── Done ───────────────────────────────────────────────────────────────────

echo -e "\n${GREEN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║       Upgrade to v1.1.0 Complete!             ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  ${BOLD}New features:${NC}"
echo -e "    • Firewall event parsing (SonicWall Enhanced Syslog)"
echo -e "    • 20 built-in security, traffic & compliance reports"
echo -e "    • Alerts dashboard with 6 pre-configured rules"
echo ""
echo -e "  ${BOLD}Access reports:${NC}  http://<server-ip>:8443/reports"
echo -e "  ${BOLD}View alerts:${NC}    http://<server-ip>:8443/alerts"
echo ""
echo -e "  ${YELLOW}Important:${NC} Ensure your SonicWall uses ${BOLD}Enhanced Syslog${NC} format"
echo -e "  for full field extraction. Go to Device → Log → Syslog and"
echo -e "  set Syslog Format to 'Enhanced Syslog'."
echo ""
echo -e "  Existing raw logs in syslog_entries are preserved."
echo -e "  New parsed data will populate fw_events going forward."
echo ""
