#!/usr/bin/env bash
# ============================================================================
# Syslog Server — Installer for Ubuntu LTS (22.04 / 24.04)
# Installs: MariaDB, Python venv, syslog receiver, web UI, TLS certs
# ============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

INSTALL_DIR="/opt/syslog-server"
CONFIG_DIR="/etc/syslog-server"
LOG_DIR="/var/log/syslog-server"
CERT_DIR="${CONFIG_DIR}/certs"
SERVICE_USER="syslog-server"
DB_NAME="syslog_db"
DB_USER="syslog"

echo -e "${CYAN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║    Sonicwall Advanced Syslog Server           ║"
echo "  ║   UDP/TCP/TLS/DTLS → MariaDB → Web UI        ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"

# ─── Pre-checks ─────────────────────────────────────────────────────────────

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Error: This script must be run as root (sudo).${NC}"
    exit 1
fi

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Prompt for passwords ──────────────────────────────────────────────────

echo -e "${YELLOW}Configuration${NC}"
echo ""

read -sp "Enter MariaDB root password (for initial setup): " MYSQL_ROOT_PASS
echo ""
read -sp "Enter password for syslog database user: " DB_PASS
echo ""
read -sp "Enter password for web admin user [default: admin]: " WEB_ADMIN_PASS
WEB_ADMIN_PASS="${WEB_ADMIN_PASS:-admin}"
echo ""
read -p "Enter server hostname/IP for TLS cert [default: $(hostname -f)]: " CERT_HOST
CERT_HOST="${CERT_HOST:-$(hostname -f)}"
echo ""

# ─── Install System Packages ───────────────────────────────────────────────

echo -e "\n${CYAN}[1/8] Installing system packages...${NC}"
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y -qq \
    mariadb-server \
    mariadb-client \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    libmariadb-dev \
    openssl \
    ufw \
    > /dev/null

echo -e "${GREEN}  ✓ System packages installed${NC}"

# ─── Configure MariaDB ─────────────────────────────────────────────────────

echo -e "\n${CYAN}[2/8] Configuring MariaDB...${NC}"

systemctl enable mariadb
systemctl start mariadb

# Secure MariaDB
mysql -u root <<-EOSQL || true
    ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASS}';
    DELETE FROM mysql.user WHERE User='';
    DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
    DROP DATABASE IF EXISTS test;
    DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
    FLUSH PRIVILEGES;
EOSQL

# Create database and user
mysql -u root -p"${MYSQL_ROOT_PASS}" <<-EOSQL
    CREATE DATABASE IF NOT EXISTS ${DB_NAME}
        CHARACTER SET utf8mb4
        COLLATE utf8mb4_unicode_ci;
    CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
    GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
    SET GLOBAL event_scheduler = ON;
    FLUSH PRIVILEGES;
EOSQL

# Import schema
mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} < "${SCRIPT_DIR}/schema.sql"

# Import firewall analytics schema (reports, alerts, parsed events)
mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} < "${SCRIPT_DIR}/schema_upgrade_v1.1.sql"

echo -e "${GREEN}  ✓ MariaDB configured, database created${NC}"

# ─── Generate TLS Certificates ─────────────────────────────────────────────

echo -e "\n${CYAN}[3/8] Generating TLS certificates...${NC}"

mkdir -p "${CERT_DIR}"

# CA certificate
openssl req -x509 -newkey rsa:4096 -days 3650 -nodes \
    -keyout "${CERT_DIR}/ca.key" \
    -out "${CERT_DIR}/ca.crt" \
    -subj "/CN=Syslog Server CA/O=SyslogServer/OU=CA" \
    2>/dev/null

# Server certificate
openssl req -newkey rsa:2048 -nodes \
    -keyout "${CERT_DIR}/server.key" \
    -out "${CERT_DIR}/server.csr" \
    -subj "/CN=${CERT_HOST}/O=SyslogServer/OU=Server" \
    2>/dev/null

# Create SAN config
cat > "${CERT_DIR}/san.cnf" <<EOF
[v3_req]
subjectAltName = @alt_names
[alt_names]
DNS.1 = ${CERT_HOST}
DNS.2 = localhost
IP.1 = 127.0.0.1
EOF

# Sign server cert with CA
openssl x509 -req -days 3650 \
    -in "${CERT_DIR}/server.csr" \
    -CA "${CERT_DIR}/ca.crt" \
    -CAkey "${CERT_DIR}/ca.key" \
    -CAcreateserial \
    -out "${CERT_DIR}/server.crt" \
    -extfile "${CERT_DIR}/san.cnf" \
    -extensions v3_req \
    2>/dev/null

rm -f "${CERT_DIR}/server.csr" "${CERT_DIR}/san.cnf" "${CERT_DIR}/ca.srl"

echo -e "${GREEN}  ✓ TLS certificates generated${NC}"
echo -e "    CA cert:     ${CERT_DIR}/ca.crt"
echo -e "    Server cert: ${CERT_DIR}/server.crt"
echo -e "    Server key:  ${CERT_DIR}/server.key"

# ─── Create Service User ───────────────────────────────────────────────────

echo -e "\n${CYAN}[4/8] Creating service user...${NC}"

if ! id "${SERVICE_USER}" &>/dev/null; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "${SERVICE_USER}"
fi

mkdir -p "${LOG_DIR}"
chown "${SERVICE_USER}:${SERVICE_USER}" "${LOG_DIR}"

echo -e "${GREEN}  ✓ Service user '${SERVICE_USER}' ready${NC}"

# ─── Install Application ───────────────────────────────────────────────────

echo -e "\n${CYAN}[5/8] Installing application...${NC}"

mkdir -p "${INSTALL_DIR}"

# Copy application files
cp "${SCRIPT_DIR}/syslog_receiver.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/web_app.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/fw_parser.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/reports.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/requirements.txt" "${INSTALL_DIR}/"
cp -r "${SCRIPT_DIR}/templates" "${INSTALL_DIR}/"

if [[ -d "${SCRIPT_DIR}/static" ]]; then
    cp -r "${SCRIPT_DIR}/static" "${INSTALL_DIR}/"
fi

# Create Python virtual environment
python3 -m venv "${INSTALL_DIR}/venv"
"${INSTALL_DIR}/venv/bin/pip" install --quiet --upgrade pip
"${INSTALL_DIR}/venv/bin/pip" install --quiet -r "${INSTALL_DIR}/requirements.txt"

echo -e "${GREEN}  ✓ Application installed to ${INSTALL_DIR}${NC}"

# ─── Write Configuration ───────────────────────────────────────────────────

echo -e "\n${CYAN}[6/8] Writing configuration...${NC}"

SECRET_KEY=$(openssl rand -hex 32)

cat > "${CONFIG_DIR}/config.json" <<EOF
{
    "db_host": "127.0.0.1",
    "db_port": 3306,
    "db_user": "${DB_USER}",
    "db_password": "${DB_PASS}",
    "db_name": "${DB_NAME}",
    "db_pool_size": 5,

    "udp_port": 514,
    "tcp_port": 514,
    "tls_port": 6514,
    "dtls_port": 6514,

    "tls_cert": "${CERT_DIR}/server.crt",
    "tls_key": "${CERT_DIR}/server.key",
    "tls_ca": "${CERT_DIR}/ca.crt",

    "batch_size": 50,
    "batch_timeout": 2.0,

    "log_file": "${LOG_DIR}/receiver.log",
    "log_level": "INFO",

    "secret_key": "${SECRET_KEY}",
    "web_host": "0.0.0.0",
    "web_port": 8443,
    "debug": false
}
EOF

# Set permissions
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${CONFIG_DIR}"
chmod 600 "${CONFIG_DIR}/config.json"
chmod 600 "${CERT_DIR}/server.key" "${CERT_DIR}/ca.key"

echo -e "${GREEN}  ✓ Configuration written to ${CONFIG_DIR}/config.json${NC}"

# ─── Install Systemd Services ──────────────────────────────────────────────

echo -e "\n${CYAN}[7/8] Installing systemd services...${NC}"

cp "${SCRIPT_DIR}/syslog-receiver.service" /etc/systemd/system/
cp "${SCRIPT_DIR}/syslog-web.service" /etc/systemd/system/

systemctl daemon-reload
systemctl enable syslog-receiver syslog-web
systemctl start syslog-receiver
systemctl start syslog-web

echo -e "${GREEN}  ✓ Services installed and started${NC}"

# ─── Configure Firewall ────────────────────────────────────────────────────

echo -e "\n${CYAN}[8/8] Configuring firewall...${NC}"

ufw allow 514/udp  comment 'Syslog UDP'   > /dev/null 2>&1 || true
ufw allow 514/tcp  comment 'Syslog TCP'   > /dev/null 2>&1 || true
ufw allow 6514/tcp comment 'Syslog TLS'   > /dev/null 2>&1 || true
ufw allow 6514/udp comment 'Syslog DTLS'  > /dev/null 2>&1 || true
ufw allow 8443/tcp comment 'Syslog Web'   > /dev/null 2>&1 || true

echo -e "${GREEN}  ✓ Firewall rules added${NC}"

# ─── Create default admin ──────────────────────────────────────────────────

# Hash the web admin password using Python
ADMIN_HASH=$("${INSTALL_DIR}/venv/bin/python3" -c "
import hashlib, secrets
salt = secrets.token_hex(16)
h = hashlib.pbkdf2_hmac('sha256', '${WEB_ADMIN_PASS}'.encode(), salt.encode(), 100000)
print(f'{salt}:{h.hex()}')
")

mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} <<-EOSQL
    INSERT INTO users (username, password_hash, display_name, role)
    VALUES ('admin', '${ADMIN_HASH}', 'Administrator', 'admin')
    ON DUPLICATE KEY UPDATE password_hash = '${ADMIN_HASH}';
EOSQL

# ─── Done ───────────────────────────────────────────────────────────────────

SERVER_IP=$(hostname -I | awk '{print $1}')

echo -e "\n${GREEN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║       Installation Complete!                  ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  ${BOLD}Web UI:${NC}        http://${SERVER_IP}:8443"
echo -e "  ${BOLD}Admin Login:${NC}   admin / (password you set)"
echo ""
echo -e "  ${BOLD}Syslog Ports:${NC}"
echo -e "    UDP/514   — Standard syslog"
echo -e "    TCP/514   — TCP syslog"
echo -e "    TCP/6514  — TLS encrypted syslog"
echo -e "    UDP/6514  — DTLS encrypted syslog"
echo ""
echo -e "  ${BOLD}Service Commands:${NC}"
echo -e "    sudo systemctl status syslog-receiver"
echo -e "    sudo systemctl status syslog-web"
echo -e "    sudo journalctl -u syslog-receiver -f"
echo ""
echo -e "  ${BOLD}Config:${NC}  ${CONFIG_DIR}/config.json"
echo -e "  ${BOLD}Logs:${NC}    ${LOG_DIR}/"
echo -e "  ${BOLD}Certs:${NC}   ${CERT_DIR}/"
echo ""
echo -e "  ${BOLD}TLS Setup for Clients:${NC}"
echo -e "    Copy ${CERT_DIR}/ca.crt to your SonicWall or"
echo -e "    other devices for TLS certificate verification."
echo ""
echo -e "  ${YELLOW}⚠  Change the default admin password immediately!${NC}"
echo ""
