-- ============================================================================
-- Syslog Server Database Schema
-- MariaDB / MySQL
-- ============================================================================

CREATE DATABASE IF NOT EXISTS syslog_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE syslog_db;

-- ─── Main syslog entries table ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS syslog_entries (
    id              BIGINT UNSIGNED AUTO_INCREMENT,
    received_at     DATETIME(3)     NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    source_ip       VARCHAR(45)     NOT NULL,
    facility        TINYINT UNSIGNED NOT NULL DEFAULT 1,
    severity        TINYINT UNSIGNED NOT NULL DEFAULT 6,
    facility_name   VARCHAR(20)     NOT NULL DEFAULT 'user',
    severity_name   VARCHAR(10)     NOT NULL DEFAULT 'info',
    hostname        VARCHAR(255)    NOT NULL,
    app_name        VARCHAR(128)    DEFAULT NULL,
    process_id      VARCHAR(32)     DEFAULT NULL,
    message         TEXT            NOT NULL,
    raw_message     TEXT            NOT NULL,

    -- Composite primary key (required for partitioning on received_at)
    PRIMARY KEY (id, received_at),

    -- Indexes for common search patterns
    INDEX idx_received_at  (received_at),
    INDEX idx_source_ip    (source_ip),
    INDEX idx_hostname     (hostname),
    INDEX idx_severity     (severity),
    INDEX idx_facility     (facility),
    INDEX idx_app_name     (app_name),
    INDEX idx_host_time    (hostname, received_at),
    INDEX idx_sev_time     (severity, received_at),

    -- Full-text index for message searching
    FULLTEXT INDEX ft_message (message)

) ENGINE=InnoDB
  ROW_FORMAT=COMPRESSED
  PARTITION BY RANGE (TO_DAYS(received_at)) (
    PARTITION p_default VALUES LESS THAN MAXVALUE
);


-- ─── Registered hosts table ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS syslog_hosts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hostname        VARCHAR(255)    NOT NULL,
    ip_address      VARCHAR(45)     NOT NULL,
    display_name    VARCHAR(255)    DEFAULT NULL,
    description     TEXT            DEFAULT NULL,
    host_type       VARCHAR(50)     DEFAULT 'generic',
    protocol        VARCHAR(20)     DEFAULT 'udp',
    port            INT UNSIGNED    DEFAULT 514,
    enabled         TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE INDEX idx_ip (ip_address),
    INDEX idx_hostname (hostname),
    INDEX idx_enabled (enabled)
) ENGINE=InnoDB;


-- ─── Application settings ──────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app_settings (
    setting_key     VARCHAR(100)    PRIMARY KEY,
    setting_value   TEXT            NOT NULL,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default settings
INSERT IGNORE INTO app_settings (setting_key, setting_value) VALUES
    ('retention_days', '90'),
    ('max_results_per_page', '100'),
    ('auto_register_hosts', 'true'),
    ('default_severity_filter', 'all');


-- ─── User accounts for web UI ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(80)     NOT NULL UNIQUE,
    password_hash   VARCHAR(255)    NOT NULL,
    display_name    VARCHAR(255)    DEFAULT NULL,
    role            ENUM('admin', 'viewer') NOT NULL DEFAULT 'viewer',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login      DATETIME        DEFAULT NULL
) ENGINE=InnoDB;


-- ─── Database user for the application ─────────────────────────────────────

-- Run these as root/admin:
-- CREATE USER IF NOT EXISTS 'syslog'@'localhost' IDENTIFIED BY 'syslog_password';
-- GRANT ALL PRIVILEGES ON syslog_db.* TO 'syslog'@'localhost';
-- FLUSH PRIVILEGES;


-- ─── Stored procedure for log cleanup ──────────────────────────────────────

DELIMITER //

CREATE PROCEDURE IF NOT EXISTS cleanup_old_logs()
BEGIN
    DECLARE retention INT DEFAULT 90;
    
    SELECT CAST(setting_value AS UNSIGNED)
    INTO retention
    FROM app_settings
    WHERE setting_key = 'retention_days';
    
    DELETE FROM syslog_entries
    WHERE received_at < DATE_SUB(NOW(), INTERVAL retention DAY);
    
    SELECT ROW_COUNT() AS deleted_rows;
END //

DELIMITER ;


-- ─── Event for automatic cleanup (runs daily at 3AM) ──────────────────────

CREATE EVENT IF NOT EXISTS evt_cleanup_old_logs
    ON SCHEDULE EVERY 1 DAY
    STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 3 HOUR)
    DO CALL cleanup_old_logs();
