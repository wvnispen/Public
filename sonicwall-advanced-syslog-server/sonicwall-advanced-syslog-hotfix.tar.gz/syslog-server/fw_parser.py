"""
SonicWall Firewall Log Parser
Extracts structured fields from SonicWall Enhanced Syslog key=value format.

Supports:
  - Traffic logs (Connection Opened/Closed, drops)
  - IPS/Threat alerts
  - VPN events (SSLVPN and IPSec)
  - Authentication events
  - Admin/config changes
  - URL/Web filtering
  - General SonicWall event messages

Also provides a generic key=value parser for non-SonicWall firewalls.
"""

import re
from datetime import datetime, timezone


# ─── Key=Value Parser ───────────────────────────────────────────────────────

# Match key=value pairs where values can be:
#   - Quoted: key="value with spaces"
#   - Unquoted: key=value
KV_RE = re.compile(
    r'(\w+)='
    r'(?:"((?:[^"\\]|\\.)*)"|(\S+))'
)


def parse_kv_pairs(text):
    """Parse key=value pairs from a syslog message body.
    Handles quoted values with spaces and escaped characters."""
    result = {}
    for match in KV_RE.finditer(text):
        key = match.group(1)
        value = match.group(2) if match.group(2) is not None else match.group(3)
        result[key] = value
    return result


# ─── SonicWall src/dst Field Parser ────────────────────────────────────────
# SonicWall packs src and dst as: IP:PORT:IFACE or IP:PORT:IFACE:HOSTNAME

def parse_endpoint(value):
    """Parse SonicWall src/dst field: IP:PORT:IFACE:NAME"""
    if not value:
        return {}

    parts = value.split(":")
    result = {}

    if len(parts) >= 1 and parts[0]:
        result["ip"] = parts[0]
    if len(parts) >= 2 and parts[1]:
        try:
            result["port"] = int(parts[1])
        except (ValueError, TypeError):
            pass
    if len(parts) >= 3 and parts[2]:
        result["iface"] = parts[2]
    if len(parts) >= 4 and parts[3]:
        result["name"] = parts[3]

    return result


# ─── Event Type Classification ──────────────────────────────────────────────

# SonicWall message IDs mapped to event types
MSG_ID_TYPES = {
    # Traffic
    98: "traffic", 537: "traffic", 41: "traffic",

    # Denied / dropped
    26: "denied", 36: "denied", 37: "denied", 38: "denied",
    39: "denied", 538: "denied", 882: "denied", 884: "denied",

    # Threats / IPS
    22: "threat", 23: "threat", 27: "threat", 28: "threat",
    82: "threat", 83: "threat", 175: "threat", 260: "threat",
    261: "threat", 501: "threat", 502: "threat", 503: "threat",
    505: "threat", 608: "threat", 1154: "threat", 1369: "threat",

    # VPN
    401: "vpn", 402: "vpn", 403: "vpn", 404: "vpn", 406: "vpn",
    411: "vpn", 413: "vpn", 428: "vpn", 440: "vpn", 441: "vpn",
    546: "vpn", 547: "vpn",

    # Auth
    24: "auth", 25: "auth", 31: "auth", 32: "auth", 33: "auth",
    34: "auth",

    # Admin
    29: "admin", 30: "admin", 506: "admin", 520: "admin",
    521: "admin", 522: "admin", 548: "admin", 860: "admin",

    # Web / URL filtering
    14: "web", 16: "web", 97: "web",

    # System
    461: "system", 598: "system",
}


def classify_event(kv, msg_id):
    """Classify event type based on message ID, action, and content."""
    # Check message ID first
    if msg_id and msg_id in MSG_ID_TYPES:
        return MSG_ID_TYPES[msg_id]

    # Check fw_action
    action = kv.get("fw_action", "").lower()
    if action in ("drop", "deny", "blocked", "block"):
        return "denied"

    # Check for IPS indicators
    if kv.get("sid") or kv.get("ipscat"):
        return "threat"

    # Check for VPN indicators
    fw_id = kv.get("id", "").lower()
    if fw_id == "sslvpn" or "vpn" in kv.get("msg", "").lower():
        return "vpn"

    # Check for web filtering
    if kv.get("Category") or kv.get("arg") or kv.get("dstname"):
        if msg_id in (97, 14, 16):
            return "web"

    # Check message content
    msg = kv.get("msg", "").lower()
    if any(w in msg for w in ["drop", "denied", "blocked", "reject"]):
        return "denied"
    if any(w in msg for w in ["attack", "scan", "flood", "spoof", "intrusion"]):
        return "threat"
    if any(w in msg for w in ["login", "logout", "auth", "password"]):
        return "auth"
    if any(w in msg for w in ["admin", "config", "rule added", "rule deleted"]):
        return "admin"

    # Check if it has traffic indicators
    if kv.get("sent") or kv.get("rcvd") or kv.get("proto"):
        return "traffic"

    return "other"


# ─── Main Parser ────────────────────────────────────────────────────────────

def parse_sonicwall(raw_message, source_ip, syslog_id=None):
    """
    Parse a SonicWall syslog message into structured fields.

    Args:
        raw_message: The raw syslog message text
        source_ip: IP address the message came from
        syslog_id: Optional ID from the syslog_entries table

    Returns:
        dict with all parsed fields, or None if not a SonicWall message
    """
    msg = raw_message
    if isinstance(msg, bytes):
        msg = msg.decode("utf-8", errors="replace")

    # Strip the PRI header if present
    msg = re.sub(r"^<\d{1,3}>", "", msg).strip()

    # Check if this looks like a SonicWall message (has id= and sn=)
    if "id=" not in msg:
        return None

    # Parse all key=value pairs
    kv = parse_kv_pairs(msg)

    if not kv.get("id"):
        return None

    # Parse message ID
    msg_id = None
    if kv.get("m"):
        try:
            msg_id = int(kv["m"])
        except (ValueError, TypeError):
            pass

    # Parse source endpoint
    src = parse_endpoint(kv.get("src", ""))
    dst = parse_endpoint(kv.get("dst", ""))

    # Parse protocol field: "tcp/https" → protocol="tcp", protocol_app="https"
    protocol = None
    protocol_app = None
    proto_raw = kv.get("proto", "")
    if "/" in proto_raw:
        parts = proto_raw.split("/", 1)
        protocol = parts[0]
        protocol_app = parts[1]
    elif proto_raw:
        protocol = proto_raw

    # Parse bytes
    def safe_int(val, default=0):
        try:
            return int(val)
        except (ValueError, TypeError):
            return default

    # Classify the event
    event_type = classify_event(kv, msg_id)

    # Build the parsed record
    record = {
        "syslog_id": syslog_id,
        "received_at": datetime.now(timezone.utc),
        "source_ip": source_ip,

        # SonicWall header
        "fw_id": kv.get("id"),
        "serial_number": kv.get("sn"),
        "fw_ip": kv.get("fw"),
        "fw_priority": safe_int(kv.get("pri")) or None,
        "category_id": safe_int(kv.get("c")) or None,
        "message_id": msg_id,
        "event_message": kv.get("msg"),
        "event_count": safe_int(kv.get("n"), 1),

        # Source
        "src_ip": src.get("ip"),
        "src_port": src.get("port"),
        "src_iface": src.get("iface"),
        "src_name": src.get("name"),
        "src_zone": kv.get("srcZone"),
        "src_mac": kv.get("srcMac"),

        # Destination
        "dst_ip": dst.get("ip"),
        "dst_port": dst.get("port"),
        "dst_iface": dst.get("iface"),
        "dst_name": dst.get("name") or kv.get("dstname"),
        "dst_zone": kv.get("dstZone"),
        "dst_mac": kv.get("dstMac"),

        # NAT
        "nat_src": kv.get("natSrc"),
        "nat_dst": kv.get("natDst"),

        # Protocol
        "protocol": protocol,
        "protocol_app": protocol_app,
        "app_id": safe_int(kv.get("app")) or None,
        "app_cat": kv.get("appcat"),
        "app_name_full": None,

        # Traffic
        "bytes_sent": safe_int(kv.get("sent")),
        "bytes_rcvd": safe_int(kv.get("rcvd")),
        "packets_sent": safe_int(kv.get("spkt")),
        "packets_rcvd": safe_int(kv.get("rpkt")),

        # Action / policy
        "fw_action": kv.get("fw_action"),
        "af_action": kv.get("af_action"),
        "rule_name": kv.get("rule"),
        "sess_type": kv.get("sess"),

        # IPS / Security
        "ips_sid": safe_int(kv.get("sid")) or None,
        "ips_category": kv.get("ipscat"),
        "ips_priority": safe_int(kv.get("ipspri")) or None,

        # URL / Web
        "url_category": kv.get("Category"),
        "url_code": safe_int(kv.get("code")) or None,
        "url_arg": kv.get("arg"),
        "url_dstname": kv.get("dstname"),

        # VPN / User
        "vpn_user": kv.get("user") or kv.get("usr"),
        "vpn_portal": kv.get("portal"),
        "vpn_domain": kv.get("domain"),

        # Additional
        "note": kv.get("note"),
        "result_code": safe_int(kv.get("result")) if kv.get("result") else None,
        "dpi_flag": safe_int(kv.get("dpi")) if kv.get("dpi") is not None else None,

        # Classification
        "event_type": event_type,
    }

    return record


def is_sonicwall_message(raw_message):
    """Quick check if a message is from a SonicWall device."""
    if isinstance(raw_message, bytes):
        raw_message = raw_message.decode("utf-8", errors="replace")
    return bool(re.search(r'\bid=(?:firewall|sslvpn)\b', raw_message))
