#!/usr/bin/env bash
# ============================================================================
# Hotfix: Performance & Stability Fixes
# Fixes: Dashboard query timeout, DB pool exhaustion, Gunicorn worker hang,
#        DTLS libcrypto error, datetime deprecation, read-only filesystem error
# ============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

INSTALL_DIR="/opt/syslog-server"
SERVICE_USER="syslog-server"

echo -e "${CYAN}${BOLD}Applying hotfix — performance & stability fixes${NC}"
echo ""

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Error: Run as root (sudo).${NC}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Stop services ──────────────────────────────────────────────────────────

echo -e "${CYAN}[1/5] Stopping services...${NC}"
systemctl stop syslog-web 2>/dev/null || true
systemctl stop syslog-receiver 2>/dev/null || true
echo -e "${GREEN}  ✓ Services stopped${NC}"

# ─── Update application files ──────────────────────────────────────────────

echo -e "${CYAN}[2/5] Updating application files...${NC}"
cp "${SCRIPT_DIR}/syslog_receiver.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/web_app.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/fw_parser.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/reports.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/requirements.txt" "${INSTALL_DIR}/"
cp -r "${SCRIPT_DIR}/templates" "${INSTALL_DIR}/"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"
echo -e "${GREEN}  ✓ Application files updated${NC}"

# ─── Update systemd service ────────────────────────────────────────────────

echo -e "${CYAN}[3/5] Updating Gunicorn service config...${NC}"
cp "${SCRIPT_DIR}/syslog-web.service" /etc/systemd/system/
systemctl daemon-reload
echo -e "${GREEN}  ✓ Service config updated${NC}"
echo -e "    Workers: 2 → 3 (with 2 threads each)"
echo -e "    Timeout: 120s → 30s"
echo -e "    Worker recycling: every 1000 requests"
echo -e "    Read-only filesystem fix applied"

# ─── Remove broken DTLS package ────────────────────────────────────────────

echo -e "${CYAN}[4/5] Cleaning up broken DTLS package...${NC}"
"${INSTALL_DIR}/venv/bin/pip" uninstall -y python3-dtls 2>/dev/null || true
echo -e "${GREEN}  ✓ Removed python3-dtls (requires OpenSSL 1.1, not available on Ubuntu 24.04)${NC}"
echo -e "    DTLS listener will fall back to plain UDP on port 6514"

# ─── Restart services ──────────────────────────────────────────────────────

echo -e "${CYAN}[5/5] Starting services...${NC}"
systemctl start syslog-receiver
systemctl start syslog-web
sleep 2

# Quick health check
if systemctl is-active --quiet syslog-receiver && systemctl is-active --quiet syslog-web; then
    echo -e "${GREEN}  ✓ Services started successfully${NC}"
else
    echo -e "${YELLOW}  ⚠ Check service status:${NC}"
    echo "    sudo systemctl status syslog-receiver"
    echo "    sudo systemctl status syslog-web"
fi

# Test web UI
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:8443/login 2>/dev/null || echo "000")
if [[ "$HTTP_CODE" == "200" ]]; then
    echo -e "${GREEN}  ✓ Web UI responding (HTTP $HTTP_CODE)${NC}"
else
    echo -e "${YELLOW}  ⚠ Web UI returned HTTP $HTTP_CODE — give it a few seconds and try again${NC}"
fi

echo -e "\n${GREEN}${BOLD}Hotfix applied successfully.${NC}"
echo ""
echo -e "  ${BOLD}Fixes applied:${NC}"
echo -e "    ✓ Dashboard uses fast approximate counts (no more full table scans)"
echo -e "    ✓ Recent critical logs query bounded to 24h (was scanning all time)"
echo -e "    ✓ DB connection pool adds health checks and auto-reconnect"
echo -e "    ✓ Gunicorn workers recycle every 1000 requests (prevents memory/connection leaks)"
echo -e "    ✓ Gunicorn timeout reduced to 30s (fast-fail instead of hanging)"
echo -e "    ✓ 3 workers × 2 threads = 6 concurrent requests (was 2 sync workers)"
echo -e "    ✓ Removed python3-dtls (was crashing on every startup)"
echo -e "    ✓ Fixed datetime.utcnow() deprecation warnings"
echo -e "    ✓ Fixed Gunicorn read-only filesystem error"
echo ""
