#!/usr/bin/env python3
"""
Syslog Server Web UI
Flask application providing:
  - Dashboard with live stats
  - Log search and filtering
  - Host management (add/edit/delete)
  - Settings management
  - User authentication
"""

import os
import sys
import json
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, jsonify, session, g, abort,
)
import mysql.connector
from mysql.connector import pooling

# ─── Configuration ──────────────────────────────────────────────────────────

CONFIG_FILE = os.environ.get("SYSLOG_CONFIG", "/etc/syslog-server/config.json")

DEFAULT_CONFIG = {
    "db_host": "127.0.0.1",
    "db_port": 3306,
    "db_user": "syslog",
    "db_password": "syslog_password",
    "db_name": "syslog_db",
    "db_pool_size": 5,
    "secret_key": secrets.token_hex(32),
    "web_host": "0.0.0.0",
    "web_port": 8443,
    "debug": False,
}


def load_config():
    config = DEFAULT_CONFIG.copy()
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                file_config = json.load(f)
            config.update(file_config)
        except Exception as e:
            print(f"Warning: Could not load config: {e}")
    return config


CONFIG = load_config()

# ─── Flask App ──────────────────────────────────────────────────────────────

app = Flask(__name__)
app.secret_key = CONFIG["secret_key"]
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=8)

# ─── Database Pool ──────────────────────────────────────────────────────────

db_pool = pooling.MySQLConnectionPool(
    pool_name="web_pool",
    pool_size=CONFIG["db_pool_size"],
    pool_reset_session=True,
    host=CONFIG["db_host"],
    port=CONFIG["db_port"],
    user=CONFIG["db_user"],
    password=CONFIG["db_password"],
    database=CONFIG["db_name"],
    charset="utf8mb4",
    collation="utf8mb4_unicode_ci",
    connection_timeout=10,
    autocommit=True,
)


def get_db():
    """Get a database connection from the pool with health check."""
    if "db" not in g:
        conn = db_pool.get_connection()
        # Verify the connection is alive; if not, reconnect
        try:
            conn.ping(reconnect=True, attempts=2, delay=1)
        except Exception:
            try:
                conn.close()
            except Exception:
                pass
            conn = db_pool.get_connection()
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        try:
            if db.is_connected():
                db.close()
        except Exception:
            pass


# ─── Auth Helpers ───────────────────────────────────────────────────────────

def hash_password(password):
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
    return f"{salt}:{h.hex()}"


def verify_password(password, stored_hash):
    salt, h = stored_hash.split(":")
    computed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
    return computed.hex() == h


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.url))
        if session.get("role") != "admin":
            abort(403)
        return f(*args, **kwargs)
    return decorated


# ─── Auth Routes ────────────────────────────────────────────────────────────

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, username, password_hash, display_name, role FROM users WHERE username = %s",
            (username,),
        )
        user = cursor.fetchone()

        if user and verify_password(password, user["password_hash"]):
            session.permanent = True
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["display_name"] = user["display_name"] or user["username"]
            session["role"] = user["role"]

            cursor.execute(
                "UPDATE users SET last_login = NOW() WHERE id = %s", (user["id"],)
            )
            conn.commit()

            next_url = request.args.get("next", url_for("dashboard"))
            return redirect(next_url)

        flash("Invalid username or password", "error")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ─── Dashboard ──────────────────────────────────────────────────────────────

@app.route("/")
@login_required
def dashboard():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Use fast approximate row count from information_schema instead of COUNT(*)
    cursor.execute("""
        SELECT table_name, table_rows
        FROM information_schema.tables
        WHERE table_schema = %s AND table_name IN ('syslog_entries', 'fw_events')
    """, (CONFIG["db_name"],))
    table_stats = {r["table_name"]: r["table_rows"] for r in cursor.fetchall()}
    total_logs = table_stats.get("syslog_entries", 0) or 0

    # Logs in last 24 hours (uses idx_received_at index)
    cursor.execute(
        "SELECT COUNT(*) as cnt FROM syslog_entries WHERE received_at >= NOW() - INTERVAL 24 HOUR"
    )
    logs_24h = cursor.fetchone()["cnt"]

    # Logs in last hour
    cursor.execute(
        "SELECT COUNT(*) as cnt FROM syslog_entries WHERE received_at >= NOW() - INTERVAL 1 HOUR"
    )
    logs_1h = cursor.fetchone()["cnt"]

    # Unique hosts (from the much smaller syslog_hosts table, or recent data only)
    cursor.execute(
        "SELECT COUNT(DISTINCT hostname) as cnt FROM syslog_entries WHERE received_at >= NOW() - INTERVAL 24 HOUR"
    )
    unique_hosts = cursor.fetchone()["cnt"]

    # Severity breakdown (last 24h)
    cursor.execute("""
        SELECT severity_name, COUNT(*) as cnt
        FROM syslog_entries
        WHERE received_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY severity_name
        ORDER BY MIN(severity)
    """)
    severity_stats = cursor.fetchall()

    # Top 10 hosts by log volume (last 24h)
    cursor.execute("""
        SELECT hostname, source_ip, COUNT(*) as cnt
        FROM syslog_entries
        WHERE received_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY hostname, source_ip
        ORDER BY cnt DESC
        LIMIT 10
    """)
    top_hosts = cursor.fetchall()

    # Recent critical/error logs (uses severity index + LIMIT, fast)
    cursor.execute("""
        SELECT received_at, hostname, severity_name, app_name, message
        FROM syslog_entries
        WHERE severity <= 3
          AND received_at >= NOW() - INTERVAL 24 HOUR
        ORDER BY received_at DESC
        LIMIT 20
    """)
    recent_critical = cursor.fetchall()

    # Hourly volume chart data (last 24h)
    cursor.execute("""
        SELECT
            DATE_FORMAT(received_at, '%%Y-%%m-%%d %%H:00') as hour_bucket,
            COUNT(*) as cnt
        FROM syslog_entries
        WHERE received_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY hour_bucket
        ORDER BY hour_bucket
    """)
    hourly_data = cursor.fetchall()

    return render_template(
        "dashboard.html",
        total_logs=total_logs,
        logs_24h=logs_24h,
        logs_1h=logs_1h,
        unique_hosts=unique_hosts,
        severity_stats=severity_stats,
        top_hosts=top_hosts,
        recent_critical=recent_critical,
        hourly_data=json.dumps([
            {"hour": r["hour_bucket"], "count": r["cnt"]} for r in hourly_data
        ]),
    )


# ─── Log Search ─────────────────────────────────────────────────────────────

@app.route("/logs")
@login_required
def logs():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Get filter parameters
    hostname = request.args.get("hostname", "").strip()
    source_ip = request.args.get("source_ip", "").strip()
    severity = request.args.get("severity", "")
    facility = request.args.get("facility", "")
    app_name = request.args.get("app_name", "").strip()
    search_text = request.args.get("search", "").strip()
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")
    page = max(1, int(request.args.get("page", 1)))
    per_page = min(200, int(request.args.get("per_page", 50)))

    # Build query
    where_clauses = []
    params = []

    if hostname:
        where_clauses.append("hostname LIKE %s")
        params.append(f"%{hostname}%")
    if source_ip:
        where_clauses.append("source_ip LIKE %s")
        params.append(f"%{source_ip}%")
    if severity:
        where_clauses.append("severity_name = %s")
        params.append(severity)
    if facility:
        where_clauses.append("facility_name = %s")
        params.append(facility)
    if app_name:
        where_clauses.append("app_name LIKE %s")
        params.append(f"%{app_name}%")
    if search_text:
        where_clauses.append("MATCH(message) AGAINST(%s IN BOOLEAN MODE)")
        params.append(search_text)
    if date_from:
        where_clauses.append("received_at >= %s")
        params.append(date_from)
    if date_to:
        where_clauses.append("received_at <= %s")
        params.append(date_to + " 23:59:59")

    where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"

    # Count total results
    cursor.execute(f"SELECT COUNT(*) as total FROM syslog_entries WHERE {where_sql}", params)
    total = cursor.fetchone()["total"]

    # Fetch results
    offset = (page - 1) * per_page
    cursor.execute(
        f"""SELECT id, received_at, source_ip, hostname, facility_name,
                   severity_name, severity, app_name, process_id, message
            FROM syslog_entries
            WHERE {where_sql}
            ORDER BY received_at DESC
            LIMIT %s OFFSET %s""",
        params + [per_page, offset],
    )
    entries = cursor.fetchall()

    # Get distinct values for filter dropdowns
    cursor.execute("SELECT DISTINCT hostname FROM syslog_entries ORDER BY hostname LIMIT 200")
    hostnames = [r["hostname"] for r in cursor.fetchall()]

    cursor.execute("SELECT DISTINCT severity_name FROM syslog_entries ORDER BY severity_name")
    severities = [r["severity_name"] for r in cursor.fetchall()]

    cursor.execute("SELECT DISTINCT facility_name FROM syslog_entries ORDER BY facility_name")
    facilities = [r["facility_name"] for r in cursor.fetchall()]

    total_pages = max(1, (total + per_page - 1) // per_page)

    return render_template(
        "logs.html",
        entries=entries,
        total=total,
        page=page,
        per_page=per_page,
        total_pages=total_pages,
        hostnames=hostnames,
        severities=severities,
        facilities=facilities,
        filters={
            "hostname": hostname,
            "source_ip": source_ip,
            "severity": severity,
            "facility": facility,
            "app_name": app_name,
            "search": search_text,
            "date_from": date_from,
            "date_to": date_to,
        },
    )


# ─── Host Management ───────────────────────────────────────────────────────

@app.route("/hosts")
@login_required
def hosts():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT h.*,
               (SELECT COUNT(*) FROM syslog_entries e WHERE e.source_ip = h.ip_address) as log_count,
               (SELECT MAX(e.received_at) FROM syslog_entries e WHERE e.source_ip = h.ip_address) as last_seen
        FROM syslog_hosts h
        ORDER BY h.display_name, h.hostname
    """)
    hosts_list = cursor.fetchall()
    return render_template("hosts.html", hosts=hosts_list)


@app.route("/hosts/add", methods=["GET", "POST"])
@login_required
def add_host():
    if request.method == "POST":
        conn = get_db()
        cursor = conn.cursor()

        hostname = request.form.get("hostname", "").strip()
        ip_address = request.form.get("ip_address", "").strip()
        display_name = request.form.get("display_name", "").strip() or hostname
        description = request.form.get("description", "").strip()
        host_type = request.form.get("host_type", "generic")
        protocol = request.form.get("protocol", "udp")
        port = int(request.form.get("port", 514))

        if not hostname or not ip_address:
            flash("Hostname and IP address are required", "error")
            return render_template("host_form.html", host=request.form, edit=False)

        try:
            cursor.execute("""
                INSERT INTO syslog_hosts
                    (hostname, ip_address, display_name, description, host_type, protocol, port)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (hostname, ip_address, display_name, description, host_type, protocol, port))
            conn.commit()
            flash(f"Host '{display_name}' added successfully", "success")
            return redirect(url_for("hosts"))
        except mysql.connector.IntegrityError:
            flash(f"A host with IP {ip_address} already exists", "error")
            return render_template("host_form.html", host=request.form, edit=False)

    return render_template("host_form.html", host={}, edit=False)


@app.route("/hosts/<int:host_id>/edit", methods=["GET", "POST"])
@login_required
def edit_host(host_id):
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        hostname = request.form.get("hostname", "").strip()
        ip_address = request.form.get("ip_address", "").strip()
        display_name = request.form.get("display_name", "").strip() or hostname
        description = request.form.get("description", "").strip()
        host_type = request.form.get("host_type", "generic")
        protocol = request.form.get("protocol", "udp")
        port = int(request.form.get("port", 514))
        enabled = 1 if request.form.get("enabled") else 0

        try:
            cursor.execute("""
                UPDATE syslog_hosts SET
                    hostname=%s, ip_address=%s, display_name=%s, description=%s,
                    host_type=%s, protocol=%s, port=%s, enabled=%s
                WHERE id=%s
            """, (hostname, ip_address, display_name, description,
                  host_type, protocol, port, enabled, host_id))
            conn.commit()
            flash(f"Host '{display_name}' updated", "success")
            return redirect(url_for("hosts"))
        except mysql.connector.IntegrityError:
            flash(f"A host with IP {ip_address} already exists", "error")

    cursor.execute("SELECT * FROM syslog_hosts WHERE id = %s", (host_id,))
    host = cursor.fetchone()
    if not host:
        abort(404)
    return render_template("host_form.html", host=host, edit=True)


@app.route("/hosts/<int:host_id>/delete", methods=["POST"])
@login_required
def delete_host(host_id):
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT display_name FROM syslog_hosts WHERE id = %s", (host_id,))
    host = cursor.fetchone()
    if host:
        cursor.execute("DELETE FROM syslog_hosts WHERE id = %s", (host_id,))
        conn.commit()
        flash(f"Host '{host['display_name']}' deleted", "success")
    return redirect(url_for("hosts"))


# ─── Settings ──────────────────────────────────────────────────────────────

@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        for key in ["retention_days", "max_results_per_page",
                     "auto_register_hosts", "default_severity_filter"]:
            value = request.form.get(key, "").strip()
            if value:
                cursor.execute("""
                    INSERT INTO app_settings (setting_key, setting_value)
                    VALUES (%s, %s)
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                """, (key, value))
        conn.commit()
        flash("Settings updated", "success")

    cursor.execute("SELECT setting_key, setting_value FROM app_settings")
    current = {r["setting_key"]: r["setting_value"] for r in cursor.fetchall()}
    return render_template("settings.html", settings=current)


# ─── User Management ───────────────────────────────────────────────────────

@app.route("/users")
@admin_required
def users():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, username, display_name, role, created_at, last_login FROM users ORDER BY username")
    users_list = cursor.fetchall()
    return render_template("users.html", users=users_list)


@app.route("/users/add", methods=["GET", "POST"])
@admin_required
def add_user():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        display_name = request.form.get("display_name", "").strip()
        role = request.form.get("role", "viewer")

        if not username or not password:
            flash("Username and password are required", "error")
            return render_template("user_form.html", user=request.form, edit=False)

        conn = get_db()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO users (username, password_hash, display_name, role)
                VALUES (%s, %s, %s, %s)
            """, (username, hash_password(password), display_name, role))
            conn.commit()
            flash(f"User '{username}' created", "success")
            return redirect(url_for("users"))
        except mysql.connector.IntegrityError:
            flash(f"Username '{username}' already exists", "error")

    return render_template("user_form.html", user={}, edit=False)


# ─── Reports ───────────────────────────────────────────────────────────────

from reports import run_report, REPORT_CATALOG


@app.route("/reports")
@login_required
def reports_index():
    """Report catalog page showing all available reports."""
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Quick stats for the reports overview
    cursor.execute("SELECT COUNT(*) as cnt FROM fw_events WHERE received_at >= NOW() - INTERVAL 24 HOUR")
    fw_events_24h = cursor.fetchone()["cnt"]

    cursor.execute("SELECT COUNT(*) as cnt FROM fw_events")
    fw_events_total = cursor.fetchone()["cnt"]

    cursor.execute("""
        SELECT event_type, COUNT(*) as cnt
        FROM fw_events
        WHERE received_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY event_type
    """)
    event_breakdown = {r["event_type"]: r["cnt"] for r in cursor.fetchall()}

    return render_template(
        "reports_index.html",
        catalog=REPORT_CATALOG,
        fw_events_24h=fw_events_24h,
        fw_events_total=fw_events_total,
        event_breakdown=event_breakdown,
    )


@app.route("/reports/<report_type>")
@login_required
def report_view(report_type):
    """Run and display a specific report."""
    period = request.args.get("period", "24h")
    limit = min(500, int(request.args.get("limit", 50)))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    result = run_report(cursor, report_type, period=period, limit=limit)

    if not result:
        abort(404)

    return render_template("report_view.html", report=result, catalog=REPORT_CATALOG)


@app.route("/api/report/<report_type>")
@login_required
def api_report(report_type):
    """API endpoint to get report data as JSON (for charts)."""
    period = request.args.get("period", "24h")
    limit = min(500, int(request.args.get("limit", 50)))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    result = run_report(cursor, report_type, period=period, limit=limit)

    if not result:
        return jsonify({"error": "Unknown report type"}), 404

    # Convert datetime objects for JSON serialization
    rows = []
    for row in result["rows"]:
        clean = {}
        for k, v in row.items():
            if isinstance(v, datetime):
                clean[k] = v.strftime("%Y-%m-%d %H:%M:%S")
            else:
                clean[k] = v
        rows.append(clean)

    return jsonify({
        "title": result["title"],
        "columns": result["columns"],
        "rows": rows,
        "chart_type": result["chart_type"],
        "period_label": result["period_label"],
        "row_count": result["row_count"],
    })


@app.route("/reports/<report_type>/export")
@login_required
def report_export_csv(report_type):
    """Export a report as CSV."""
    import csv
    import io

    period = request.args.get("period", "24h")
    limit = min(10000, int(request.args.get("limit", 1000)))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    result = run_report(cursor, report_type, period=period, limit=limit)

    if not result:
        abort(404)

    output = io.StringIO()
    if result["rows"]:
        fieldnames = list(result["rows"][0].keys())
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        for row in result["rows"]:
            clean = {}
            for k, v in row.items():
                if isinstance(v, datetime):
                    clean[k] = v.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    clean[k] = v
            writer.writerow(clean)

    from flask import Response
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={report_type}_{period}.csv"},
    )


# ─── Alerts Dashboard ──────────────────────────────────────────────────────

@app.route("/alerts")
@login_required
def alerts_dashboard():
    """View active and recent alerts."""
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT al.*, ar.name as rule_name, ar.severity as rule_severity
        FROM alert_log al
        JOIN alert_rules ar ON al.rule_id = ar.id
        ORDER BY al.triggered_at DESC
        LIMIT 100
    """)
    recent_alerts = cursor.fetchall()

    cursor.execute("SELECT * FROM alert_rules ORDER BY name")
    rules = cursor.fetchall()

    cursor.execute("""
        SELECT ar.name, ar.severity, COUNT(al.id) as trigger_count,
               MAX(al.triggered_at) as last_triggered
        FROM alert_rules ar
        LEFT JOIN alert_log al ON ar.id = al.rule_id
            AND al.triggered_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY ar.id, ar.name, ar.severity
        ORDER BY trigger_count DESC
    """)
    rule_stats = cursor.fetchall()

    return render_template("alerts.html",
                           alerts=recent_alerts,
                           rules=rules,
                           rule_stats=rule_stats)


# ─── API Endpoints ──────────────────────────────────────────────────────────

@app.route("/api/stats")
@login_required
def api_stats():
    """Real-time stats for dashboard auto-refresh."""
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT COUNT(*) as cnt FROM syslog_entries WHERE received_at >= NOW() - INTERVAL 1 HOUR"
    )
    logs_1h = cursor.fetchone()["cnt"]

    cursor.execute("""
        SELECT severity_name, COUNT(*) as cnt
        FROM syslog_entries
        WHERE received_at >= NOW() - INTERVAL 1 HOUR
        GROUP BY severity_name
    """)
    severity = {r["severity_name"]: r["cnt"] for r in cursor.fetchall()}

    return jsonify({"logs_1h": logs_1h, "severity": severity})


@app.route("/api/logs/recent")
@login_required
def api_recent_logs():
    """Fetch most recent log entries (for live tail)."""
    limit = min(100, int(request.args.get("limit", 20)))
    after_id = request.args.get("after_id", 0, type=int)

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    if after_id:
        cursor.execute("""
            SELECT id, received_at, source_ip, hostname, severity_name, severity,
                   app_name, message
            FROM syslog_entries
            WHERE id > %s
            ORDER BY id DESC
            LIMIT %s
        """, (after_id, limit))
    else:
        cursor.execute("""
            SELECT id, received_at, source_ip, hostname, severity_name, severity,
                   app_name, message
            FROM syslog_entries
            ORDER BY id DESC
            LIMIT %s
        """, (limit,))

    entries = cursor.fetchall()
    # Convert datetime objects to strings
    for e in entries:
        if isinstance(e["received_at"], datetime):
            e["received_at"] = e["received_at"].strftime("%Y-%m-%d %H:%M:%S")

    return jsonify(entries)


@app.route("/api/export")
@login_required
def api_export():
    """Export filtered logs as CSV."""
    import csv
    import io

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    hostname = request.args.get("hostname", "")
    severity = request.args.get("severity", "")
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")

    where = []
    params = []
    if hostname:
        where.append("hostname = %s")
        params.append(hostname)
    if severity:
        where.append("severity_name = %s")
        params.append(severity)
    if date_from:
        where.append("received_at >= %s")
        params.append(date_from)
    if date_to:
        where.append("received_at <= %s")
        params.append(date_to + " 23:59:59")

    where_sql = " AND ".join(where) if where else "1=1"

    cursor.execute(
        f"""SELECT received_at, source_ip, hostname, facility_name,
                   severity_name, app_name, process_id, message
            FROM syslog_entries WHERE {where_sql}
            ORDER BY received_at DESC LIMIT 10000""",
        params,
    )
    rows = cursor.fetchall()

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=[
        "received_at", "source_ip", "hostname", "facility_name",
        "severity_name", "app_name", "process_id", "message",
    ])
    writer.writeheader()
    for row in rows:
        if isinstance(row["received_at"], datetime):
            row["received_at"] = row["received_at"].strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow(row)

    from flask import Response
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=syslog_export.csv"},
    )


# ─── Template Context ──────────────────────────────────────────────────────

@app.context_processor
def inject_globals():
    return {
        "now": datetime.now(timezone.utc),
        "app_name": "SonicWall Advanced Syslog",
    }


# ─── Initial Setup ─────────────────────────────────────────────────────────

def ensure_admin_exists():
    """Create default admin user if none exists."""
    try:
        conn = db_pool.get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'")
        if cursor.fetchone()["cnt"] == 0:
            cursor.execute("""
                INSERT INTO users (username, password_hash, display_name, role)
                VALUES ('admin', %s, 'Administrator', 'admin')
            """, (hash_password("admin"),))
            conn.commit()
            print("=" * 50)
            print("  Default admin user created!")
            print("  Username: admin")
            print("  Password: admin")
            print("  ** CHANGE THIS IMMEDIATELY **")
            print("=" * 50)
        conn.close()
    except Exception as e:
        print(f"Warning: Could not check/create admin user: {e}")


# ─── Main ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    ensure_admin_exists()
    app.run(
        host=CONFIG.get("web_host", "0.0.0.0"),
        port=CONFIG.get("web_port", 8443),
        debug=CONFIG.get("debug", False),
    )
