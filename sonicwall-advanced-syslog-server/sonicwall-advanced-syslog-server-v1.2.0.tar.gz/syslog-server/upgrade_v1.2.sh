#!/usr/bin/env bash
# ============================================================================
# Sonicwall Advanced Syslog Server — Upgrade to v1.2.0
# From: v1.1.0 or v1.1.1
# Adds: Pre-computed dashboard stats, hourly rollup table, stats worker
# Includes all v1.1.1 fixes if not yet applied
# ============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

INSTALL_DIR="/opt/syslog-server"
CONFIG_DIR="/etc/syslog-server"
SERVICE_USER="syslog-server"

echo -e "${CYAN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║  Sonicwall Advanced Syslog Server             ║"
echo "  ║  Upgrade to v1.2.0 — Instant Dashboard        ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Error: Run as root (sudo).${NC}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

read -sp "MariaDB root password: " MYSQL_ROOT_PASS
echo ""

DB_NAME="syslog_db"
if [[ -f "${CONFIG_DIR}/config.json" ]]; then
    DB_NAME=$(python3 -c "import json; print(json.load(open('${CONFIG_DIR}/config.json')).get('db_name','syslog_db'))" 2>/dev/null || echo "syslog_db")
fi

# ─── Stop services ──────────────────────────────────────────────────────────

echo -e "\n${CYAN}[1/7] Stopping services...${NC}"
systemctl stop syslog-web 2>/dev/null || true
systemctl stop syslog-receiver 2>/dev/null || true
echo -e "${GREEN}  ✓ Services stopped${NC}"

# ─── Apply v1.1 schema if not already present ──────────────────────────────

echo -e "\n${CYAN}[2/7] Checking database schema...${NC}"

HAS_FW=$(mysql -u root -p"${MYSQL_ROOT_PASS}" -sN ${DB_NAME} -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${DB_NAME}' AND table_name='fw_events';" 2>/dev/null || echo "0")
if [[ "$HAS_FW" == "0" ]]; then
    echo "  Applying v1.1 schema (fw_events, alerts)..."
    mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} < "${SCRIPT_DIR}/schema_upgrade_v1.1.sql"
    echo -e "${GREEN}  ✓ v1.1 schema applied${NC}"
else
    echo -e "  ✓ v1.1 schema already present"
fi

# ─── Apply v1.2 schema ─────────────────────────────────────────────────────

echo -e "\n${CYAN}[3/7] Applying v1.2 schema (dashboard stats, hourly rollups)...${NC}"
mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} < "${SCRIPT_DIR}/schema_upgrade_v1.2.sql"

# Ensure event scheduler is on
mysql -u root -p"${MYSQL_ROOT_PASS}" -e "SET GLOBAL event_scheduler = ON;"

echo -e "${GREEN}  ✓ v1.2 schema applied${NC}"

# ─── MariaDB performance tuning ────────────────────────────────────────────

echo -e "\n${CYAN}[4/7] Applying MariaDB performance tuning...${NC}"

cp "${SCRIPT_DIR}/mariadb-tuning.cnf" /etc/mysql/mariadb.conf.d/99-syslog-tuning.cnf

TOTAL_RAM_MB=$(free -m | awk '/^Mem:/{print $2}')
if [ "${TOTAL_RAM_MB}" -ge 16000 ]; then
    POOL_SIZE="4G"
elif [ "${TOTAL_RAM_MB}" -ge 8000 ]; then
    POOL_SIZE="2G"
elif [ "${TOTAL_RAM_MB}" -ge 4000 ]; then
    POOL_SIZE="1G"
else
    POOL_SIZE="512M"
fi
sed -i "s/^innodb_buffer_pool_size = .*/innodb_buffer_pool_size = ${POOL_SIZE}/" \
    /etc/mysql/mariadb.conf.d/99-syslog-tuning.cnf

systemctl restart mariadb
sleep 2

if systemctl is-active --quiet mariadb; then
    echo -e "${GREEN}  ✓ MariaDB tuned (buffer pool: ${POOL_SIZE})${NC}"
else
    echo -e "${RED}  ✗ MariaDB failed to restart${NC}"
    exit 1
fi

# ─── Seed initial stats ────────────────────────────────────────────────────

echo -e "\n${CYAN}[5/7] Seeding initial dashboard stats (this may take a moment)...${NC}"
mysql -u root -p"${MYSQL_ROOT_PASS}" ${DB_NAME} -e "CALL refresh_dashboard_stats();" 2>/dev/null || true
echo -e "${GREEN}  ✓ Dashboard stats seeded${NC}"

# ─── Update application files ──────────────────────────────────────────────

echo -e "\n${CYAN}[6/7] Updating application files...${NC}"

cp "${SCRIPT_DIR}/syslog_receiver.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/web_app.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/fw_parser.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/reports.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/stats_worker.py" "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/requirements.txt" "${INSTALL_DIR}/"
cp -r "${SCRIPT_DIR}/templates" "${INSTALL_DIR}/"

if [[ -d "${SCRIPT_DIR}/static" ]]; then
    cp -r "${SCRIPT_DIR}/static" "${INSTALL_DIR}/"
fi

cp "${SCRIPT_DIR}/syslog-web.service" /etc/systemd/system/
cp "${SCRIPT_DIR}/syslog-receiver.service" /etc/systemd/system/
systemctl daemon-reload

chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"

# Remove broken DTLS package
"${INSTALL_DIR}/venv/bin/pip" uninstall -y python3-dtls 2>/dev/null || true

echo -e "${GREEN}  ✓ Application files updated${NC}"

# ─── Restart services ──────────────────────────────────────────────────────

echo -e "\n${CYAN}[7/7] Starting services...${NC}"

systemctl start syslog-receiver
systemctl start syslog-web
sleep 3

ERRORS=0
for SVC in syslog-receiver syslog-web mariadb; do
    if systemctl is-active --quiet "$SVC"; then
        echo -e "${GREEN}  ✓ ${SVC} running${NC}"
    else
        echo -e "${RED}  ✗ ${SVC} failed${NC}"
        ERRORS=$((ERRORS + 1))
    fi
done

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 http://localhost:8443/login 2>/dev/null || echo "000")
if [[ "$HTTP_CODE" == "200" ]]; then
    echo -e "${GREEN}  ✓ Web UI responding (HTTP 200)${NC}"
else
    echo -e "${YELLOW}  ⚠ Web UI HTTP ${HTTP_CODE}${NC}"
fi

echo -e "\n${GREEN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║       Upgrade to v1.2.0 Complete!             ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  ${BOLD}What's new:${NC}"
echo -e "    ✓ Dashboard loads instantly (pre-computed stats, updated every 60s)"
echo -e "    ✓ Hourly rollup table replaces multi-million row scans"
echo -e "    ✓ Background stats worker in syslog receiver"
echo -e "    ✓ MariaDB buffer pool tuned to ${POOL_SIZE}"
echo -e "    ✓ All v1.1.1 stability fixes included"
echo ""
echo -e "  ${BOLD}Dashboard data:${NC} Stats refresh every 60 seconds automatically."
echo -e "  The first refresh after upgrade may take a moment to populate."
echo ""
