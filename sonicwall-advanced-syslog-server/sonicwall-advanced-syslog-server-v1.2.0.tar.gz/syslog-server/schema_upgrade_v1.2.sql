-- ============================================================================
-- Sonicwall Advanced Syslog Server v1.2.0 — Schema Upgrade
-- Adds: Pre-computed dashboard stats for instant page loads
-- Run AFTER schema.sql and schema_upgrade_v1.1.sql
-- ============================================================================

USE syslog_db;

-- ─── Pre-computed dashboard statistics ─────────────────────────────────────
-- Refreshed every 60 seconds by the stats worker thread.
-- Dashboard reads from this single table instead of scanning millions of rows.

CREATE TABLE IF NOT EXISTS dashboard_stats (
    stat_key        VARCHAR(100)    PRIMARY KEY,
    stat_value      BIGINT          NOT NULL DEFAULT 0,
    stat_json       JSON            DEFAULT NULL,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;


-- ─── Hourly rollup table ──────────────────────────────────────────────────
-- One row per hour per host. Updated incrementally by the stats worker.
-- Dashboard charts and "last 24h" counts read from here instead of syslog_entries.

CREATE TABLE IF NOT EXISTS hourly_stats (
    hour_bucket     DATETIME        NOT NULL,
    hostname        VARCHAR(255)    NOT NULL,
    source_ip       VARCHAR(45)     NOT NULL,
    event_count     INT UNSIGNED    NOT NULL DEFAULT 0,
    bytes_sent      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    bytes_rcvd      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    denied_count    INT UNSIGNED    NOT NULL DEFAULT 0,
    threat_count    INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_emerg  INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_alert  INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_crit   INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_err    INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_warning INT UNSIGNED   NOT NULL DEFAULT 0,
    severity_notice INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_info   INT UNSIGNED    NOT NULL DEFAULT 0,
    severity_debug  INT UNSIGNED    NOT NULL DEFAULT 0,

    PRIMARY KEY (hour_bucket, hostname, source_ip),
    INDEX idx_hs_hour (hour_bucket),
    INDEX idx_hs_host (hostname)
) ENGINE=InnoDB;


-- ─── Stored procedure: Refresh dashboard stats ─────────────────────────────

DROP PROCEDURE IF EXISTS refresh_dashboard_stats;

DELIMITER //

CREATE PROCEDURE refresh_dashboard_stats()
BEGIN
    -- Total logs (fast approximate from information_schema)
    INSERT INTO dashboard_stats (stat_key, stat_value)
    SELECT 'total_logs', IFNULL(table_rows, 0)
    FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'syslog_entries'
    ON DUPLICATE KEY UPDATE stat_value = VALUES(stat_value), updated_at = NOW();

    -- Total fw_events
    INSERT INTO dashboard_stats (stat_key, stat_value)
    SELECT 'total_fw_events', IFNULL(table_rows, 0)
    FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'fw_events'
    ON DUPLICATE KEY UPDATE stat_value = VALUES(stat_value), updated_at = NOW();

    -- Logs last 24h (from hourly_stats rollup — fast)
    INSERT INTO dashboard_stats (stat_key, stat_value)
    SELECT 'logs_24h', IFNULL(SUM(event_count), 0)
    FROM hourly_stats
    WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
    ON DUPLICATE KEY UPDATE stat_value = VALUES(stat_value), updated_at = NOW();

    -- Logs last 1h
    INSERT INTO dashboard_stats (stat_key, stat_value)
    SELECT 'logs_1h', IFNULL(SUM(event_count), 0)
    FROM hourly_stats
    WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 1 HOUR, '%Y-%m-%d %H:00:00')
    ON DUPLICATE KEY UPDATE stat_value = VALUES(stat_value), updated_at = NOW();

    -- Unique hosts (24h)
    INSERT INTO dashboard_stats (stat_key, stat_value)
    SELECT 'unique_hosts_24h', COUNT(DISTINCT hostname)
    FROM hourly_stats
    WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
    ON DUPLICATE KEY UPDATE stat_value = VALUES(stat_value), updated_at = NOW();

    -- Severity breakdown (24h) as JSON
    INSERT INTO dashboard_stats (stat_key, stat_value, stat_json)
    SELECT 'severity_24h', 0, JSON_ARRAYAGG(
        JSON_OBJECT('severity_name', sev, 'cnt', cnt)
    )
    FROM (
        SELECT 'emerg' as sev, SUM(severity_emerg) as cnt FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'alert', SUM(severity_alert) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'crit', SUM(severity_crit) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'err', SUM(severity_err) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'warning', SUM(severity_warning) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'notice', SUM(severity_notice) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'info', SUM(severity_info) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        UNION ALL SELECT 'debug', SUM(severity_debug) FROM hourly_stats WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
    ) t WHERE cnt > 0
    ON DUPLICATE KEY UPDATE stat_json = VALUES(stat_json), updated_at = NOW();

    -- Top 10 hosts (24h) as JSON
    INSERT INTO dashboard_stats (stat_key, stat_value, stat_json)
    SELECT 'top_hosts_24h', 0, JSON_ARRAYAGG(
        JSON_OBJECT('hostname', hostname, 'source_ip', source_ip, 'cnt', total)
    )
    FROM (
        SELECT hostname, source_ip, SUM(event_count) as total
        FROM hourly_stats
        WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        GROUP BY hostname, source_ip
        ORDER BY total DESC
        LIMIT 10
    ) t
    ON DUPLICATE KEY UPDATE stat_json = VALUES(stat_json), updated_at = NOW();

    -- Hourly volume chart data (24h) as JSON
    INSERT INTO dashboard_stats (stat_key, stat_value, stat_json)
    SELECT 'hourly_volume_24h', 0, JSON_ARRAYAGG(
        JSON_OBJECT('hour', hour_bucket, 'count', total)
    )
    FROM (
        SELECT DATE_FORMAT(hour_bucket, '%Y-%m-%d %H:00') as hour_bucket,
               SUM(event_count) as total
        FROM hourly_stats
        WHERE hour_bucket >= DATE_FORMAT(NOW() - INTERVAL 24 HOUR, '%Y-%m-%d %H:00:00')
        GROUP BY DATE_FORMAT(hour_bucket, '%Y-%m-%d %H:00')
        ORDER BY hour_bucket
    ) t
    ON DUPLICATE KEY UPDATE stat_json = VALUES(stat_json), updated_at = NOW();

    -- Cleanup old hourly_stats (keep 90 days)
    DELETE FROM hourly_stats WHERE hour_bucket < NOW() - INTERVAL 90 DAY;
END //

DELIMITER ;


-- ─── MariaDB event to refresh stats every minute ──────────────────────────

CREATE EVENT IF NOT EXISTS evt_refresh_dashboard
    ON SCHEDULE EVERY 1 MINUTE
    DO CALL refresh_dashboard_stats();
