"""
Stats Worker
Background thread that incrementally rolls up syslog_entries and fw_events
into the hourly_stats summary table every 60 seconds.

The dashboard reads from hourly_stats + dashboard_stats instead of
scanning millions of rows in the main tables.
"""

import logging
import threading
import time
from datetime import datetime, timezone

logger = logging.getLogger("syslog-receiver.stats")


class StatsWorker(threading.Thread):
    """Periodically rolls up recent data into hourly_stats and triggers
    the dashboard_stats refresh stored procedure."""

    def __init__(self, db_pool, interval=60):
        super().__init__(daemon=True)
        self.db_pool = db_pool
        self.interval = interval
        self.running = False

    def run(self):
        self.running = True
        logger.info(f"Stats worker started (interval={self.interval}s)")

        # Wait a few seconds for data to start flowing
        time.sleep(10)

        while self.running:
            try:
                self._rollup()
            except Exception as e:
                logger.error(f"Stats worker error: {e}")

            # Sleep in small increments so we can stop cleanly
            for _ in range(self.interval):
                if not self.running:
                    break
                time.sleep(1)

        logger.info("Stats worker stopped")

    def stop(self):
        self.running = False

    def _rollup(self):
        """Roll up the current hour's data into hourly_stats, then refresh dashboard."""
        conn = None
        try:
            conn = self.db_pool.get_connection()
            cursor = conn.cursor()

            # ── Roll up syslog_entries into hourly_stats ──
            # We use INSERT ... ON DUPLICATE KEY UPDATE to upsert.
            # Only process the last 2 hours to keep it fast.
            cursor.execute("""
                INSERT INTO hourly_stats
                    (hour_bucket, hostname, source_ip, event_count,
                     severity_emerg, severity_alert, severity_crit, severity_err,
                     severity_warning, severity_notice, severity_info, severity_debug)
                SELECT
                    DATE_FORMAT(received_at, '%%Y-%%m-%%d %%H:00:00') as hb,
                    hostname,
                    source_ip,
                    COUNT(*) as event_count,
                    SUM(CASE WHEN severity = 0 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 1 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 2 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 3 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 4 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 5 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 6 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN severity = 7 THEN 1 ELSE 0 END)
                FROM syslog_entries
                WHERE received_at >= DATE_FORMAT(NOW() - INTERVAL 2 HOUR, '%%Y-%%m-%%d %%H:00:00')
                GROUP BY hb, hostname, source_ip
                ON DUPLICATE KEY UPDATE
                    event_count = VALUES(event_count),
                    severity_emerg = VALUES(severity_emerg),
                    severity_alert = VALUES(severity_alert),
                    severity_crit = VALUES(severity_crit),
                    severity_err = VALUES(severity_err),
                    severity_warning = VALUES(severity_warning),
                    severity_notice = VALUES(severity_notice),
                    severity_info = VALUES(severity_info),
                    severity_debug = VALUES(severity_debug)
            """)

            # ── Roll up fw_events bytes/denied/threat counts ──
            cursor.execute("""
                INSERT INTO hourly_stats
                    (hour_bucket, hostname, source_ip, event_count,
                     bytes_sent, bytes_rcvd, denied_count, threat_count)
                SELECT
                    DATE_FORMAT(received_at, '%%Y-%%m-%%d %%H:00:00') as hb,
                    COALESCE(src_ip, source_ip) as hostname,
                    source_ip,
                    0,
                    SUM(bytes_sent),
                    SUM(bytes_rcvd),
                    SUM(CASE WHEN event_type = 'denied' THEN 1 ELSE 0 END),
                    SUM(CASE WHEN event_type = 'threat' THEN 1 ELSE 0 END)
                FROM fw_events
                WHERE received_at >= DATE_FORMAT(NOW() - INTERVAL 2 HOUR, '%%Y-%%m-%%d %%H:00:00')
                GROUP BY hb, hostname, source_ip
                ON DUPLICATE KEY UPDATE
                    bytes_sent = VALUES(bytes_sent),
                    bytes_rcvd = VALUES(bytes_rcvd),
                    denied_count = VALUES(denied_count),
                    threat_count = VALUES(threat_count)
            """)

            conn.commit()

            # ── Refresh dashboard_stats via stored procedure ──
            cursor.callproc("refresh_dashboard_stats")
            conn.commit()

            logger.debug("Stats rollup completed")

        except Exception as e:
            logger.error(f"Stats rollup error: {e}")
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass
