# SonicWall Flow Reporter - Native Linux Installation

**Version 1.4.2**

Real-time network flow monitoring and reporting for SonicWall firewalls using IPFIX/NetFlow.

## What's New in v1.4.2

### 🏷️ Device Name Resolution in Dashboards
- **All dashboards now display device names** from the Identity Database instead of raw IP addresses
- Internal IP addresses are automatically resolved to their registered names
- Falls back gracefully to IP address if no name is registered
- Works with both direct IP mappings and subnet-based mappings

### Dashboard Improvements
- Users & Top Talkers dashboard shows device/user names
- Flow Explorer shows source and destination names
- Network Traffic dashboard displays friendly names
- All tables support name-based filtering and searching

### Technical Changes
- Added `src_user_name` and `dst_user_name` display in all user-facing panels
- Dashboard queries now include identity-enriched fields
- Improved field mappings for better Grafana compatibility

---

## Features (v1.4.x)

### 🌍 GeoIP Location Mapping
- World map showing traffic destinations by country
- City-level geolocation for destination IPs
- ASN/Organization identification (ISP, cloud provider, etc.)
- Requires free MaxMind GeoLite2 database

### 🛡️ Threat Intelligence Integration
- Automatic IP reputation checking against multiple threat feeds
- Emerging Threats, Feodo Tracker, Spamhaus DROP
- Custom local blocklist support
- Real-time alerting on malicious traffic

### 📊 Application Classification
- Traffic categorization by application type
- Port-based service identification (HTTP, HTTPS, SSH, RDP, etc.)
- Productivity classification (Productive, Unproductive, Neutral)
- URL-based categorization (Streaming, Social Media, Business)

### ⚠️ Risk Scoring
- Automatic risk score (0-100) for each flow
- Based on: port risk, data volume, app category, threat intel
- High-risk flow alerting

### 🔍 DNS Reverse Lookup
- Hostname resolution for destination IPs
- Cached for performance
- Makes dashboards more readable

### 📈 Dashboards
- **Overview** - System health and traffic summary
- **Users & Top Talkers** - User activity with device names
- **Applications** - Traffic by application
- **Network Traffic** - Bandwidth analysis
- **Flow Explorer** - Detailed flow inspection with device names
- **GeoIP & World Map** - Geographic traffic visualization
- **Threat Intelligence** - Security monitoring and alerts
- **Applications & Productivity** - Traffic classification

### 🔔 Alerting (Grafana)
- Pre-configured alert rules for common scenarios
- Threat detection alerts
- High bandwidth user alerts
- Risky port usage alerts
- Unusual country access alerts

---

## Requirements

- Ubuntu 24.04 LTS (or compatible)
- SonicWall Gen 8 firewall with IPFIX enabled
- 4GB RAM minimum (8GB recommended)
- 50GB disk space for flow data

## Quick Start

```bash
# Download and extract
tar -xzf sonicwall-flow-reporter-1.4.2.tar.gz
cd sonicwall-flow-reporter-native

# Install
sudo ./scripts/install-native.sh

# Configure your firewall IP
sudo nano /opt/sonicwall-flow-reporter/collector/.env

# Restart collector
sudo systemctl restart swfr-collector
```

## Identity Database Setup

To display device names instead of IP addresses:

1. Access the Identity UI at `http://your-server:8080`
2. Add device mappings:
   - **Single IP**: Map individual devices (servers, printers, etc.)
   - **Subnet/CIDR**: Map IP ranges (DHCP pools, VLANs)
3. Import from CSV or sync from SonicWall SSO

### CSV Import Format
```csv
ip_address,user_id,user_name,department,location
192.168.1.10,server01,File Server,IT,Server Room
192.168.1.100,jsmith,John Smith,Engineering,Floor 2
```

### Subnet Mapping Example
- Subnet: `192.168.10.0/24`
- User Name: `Guest WiFi`
- Department: `Guest Network`

## Accessing Dashboards

- **Grafana**: http://your-server:3000 (admin/admin)
- **Identity UI**: http://your-server:8080 (admin/admin)

## Upgrading from 1.4.1

```bash
# Stop services
sudo systemctl stop swfr-collector swfr-identity

# Backup dashboards (optional)
cp -r /var/lib/grafana/dashboards /var/lib/grafana/dashboards.bak

# Extract new version
tar -xzf sonicwall-flow-reporter-1.4.2.tar.gz
cd sonicwall-flow-reporter-native

# Copy new dashboards
sudo cp grafana/dashboards/*.json /var/lib/grafana/dashboards/

# Restart services
sudo systemctl start swfr-collector swfr-identity
sudo systemctl restart grafana-server
```

## Configuration

### Environment Variables

Edit `/opt/sonicwall-flow-reporter/collector/.env`:

```bash
# Elasticsearch
ES_HOST=127.0.0.1
ES_PORT=9200

# IPFIX Collector
IPFIX_LISTEN_IP=0.0.0.0
IPFIX_LISTEN_PORT=2055
ALLOWED_SOURCES=192.168.1.1  # Your firewall IP

# Enrichment Modules
ENABLE_GEOIP=true
ENABLE_DNS=true
ENABLE_THREAT_INTEL=true
GEOIP_DB_DIR=/opt/sonicwall-flow-reporter/geoip
```

## Troubleshooting

### Device names not showing
1. Check Identity UI has mappings for the IPs
2. Verify collector is running: `systemctl status swfr-collector`
3. Check enrichment is working: `journalctl -u swfr-collector -f`
4. New flows will show names; existing flows won't be updated

### Dashboard shows "No data"
1. Verify Elasticsearch is running: `curl http://localhost:9200`
2. Check for flow data: `curl http://localhost:9200/flows-*/_count`
3. Verify firewall IPFIX is configured correctly

## License

MIT License - See LICENSE file

## Support

- GitHub Issues: https://github.com/sonicwall/flow-reporter/issues
- Documentation: https://docs.sonicwall.com/flow-reporter
