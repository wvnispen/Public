#!/bin/bash
#
# SonicWall Flow Reporter - Upgrade to v1.4.2
# 
# This script upgrades from v1.4.1 to v1.4.2
# Main change: Dashboard updates to display device names from Identity Database
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

INSTALL_DIR="/opt/sonicwall-flow-reporter"
GRAFANA_DASHBOARD_DIR="/var/lib/grafana/dashboards"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     SonicWall Flow Reporter - Upgrade to v1.4.2               ║${NC}"
echo -e "${CYAN}║     Device Names in Dashboards Update                         ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}ERROR: This script must be run as root (use sudo)${NC}"
   exit 1
fi

# Check if SWFR is installed
if [ ! -d "$INSTALL_DIR" ]; then
    echo -e "${RED}ERROR: SonicWall Flow Reporter not found at $INSTALL_DIR${NC}"
    echo "Please run the full installation script first."
    exit 1
fi

echo -e "${GREEN}Starting upgrade to v1.4.2...${NC}"
echo ""

# Backup current dashboards
echo -e "${GREEN}[1/4] Backing up current dashboards...${NC}"
BACKUP_DIR="$GRAFANA_DASHBOARD_DIR.backup-$(date +%Y%m%d-%H%M%S)"
if [ -d "$GRAFANA_DASHBOARD_DIR" ]; then
    cp -r "$GRAFANA_DASHBOARD_DIR" "$BACKUP_DIR"
    echo "  Backup created: $BACKUP_DIR"
else
    echo "  No existing dashboards to backup"
fi

# Stop services briefly
echo -e "\n${GREEN}[2/4] Updating dashboards...${NC}"

# Copy new dashboards
if [ -d "$BASE_DIR/grafana/dashboards" ]; then
    mkdir -p "$GRAFANA_DASHBOARD_DIR"
    
    # Copy each dashboard
    for dashboard in "$BASE_DIR/grafana/dashboards/"*.json; do
        if [ -f "$dashboard" ]; then
            filename=$(basename "$dashboard")
            cp -f "$dashboard" "$GRAFANA_DASHBOARD_DIR/$filename"
            echo "  Updated: $filename"
        fi
    done
    
    # Set permissions
    chown -R grafana:grafana "$GRAFANA_DASHBOARD_DIR"
    chmod -R 644 "$GRAFANA_DASHBOARD_DIR"/*.json
else
    echo -e "${RED}ERROR: Dashboard files not found in $BASE_DIR/grafana/dashboards${NC}"
    exit 1
fi

# Update version file
echo -e "\n${GREEN}[3/4] Updating version...${NC}"
echo "1.4.2" > "$INSTALL_DIR/VERSION"
echo "  Version updated to 1.4.2"

# Restart Grafana to pick up new dashboards
echo -e "\n${GREEN}[4/4] Restarting Grafana...${NC}"
systemctl restart grafana-server
echo "  Grafana restarted"

# Wait for Grafana
echo -n "  Waiting for Grafana..."
for i in {1..30}; do
    if curl -s http://127.0.0.1:3000/api/health > /dev/null 2>&1; then
        echo -e " ${GREEN}ready${NC}"
        break
    fi
    echo -n "."
    sleep 1
done

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     Upgrade to v1.4.2 Complete!                               ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}What's New in v1.4.2:${NC}"
echo "  • Dashboards now display device/user names from Identity Database"
echo "  • Internal IPs automatically resolved to registered names"
echo "  • New columns: 'Device/User', 'Src Name', 'Dst Name'"
echo "  • Department and Location breakdowns added"
echo ""
echo -e "${CYAN}To see device names:${NC}"
echo "  1. Add device mappings in Identity UI: http://$(hostname -I | awk '{print $1}'):8080"
echo "  2. New flows will show device names automatically"
echo "  3. Existing flows will continue showing IP addresses"
echo ""
echo -e "${CYAN}Access Grafana:${NC} http://$(hostname -I | awk '{print $1}'):3000"
echo ""
echo -e "${YELLOW}Note: Dashboard backup saved to: $BACKUP_DIR${NC}"
