#!/usr/bin/env python3
"""
Syslog Receiver Daemon
Listens on:
  - UDP/514   (standard syslog)
  - TCP/514   (standard syslog over TCP)
  - TCP/6514  (TLS encrypted syslog)
  - UDP/6514  (DTLS encrypted syslog)

Parses incoming syslog messages and writes them to MariaDB.
"""

import os
import sys
import ssl
import socket
import signal
import logging
import threading
import re
import json
import time
from datetime import datetime
from queue import Queue, Empty
from pathlib import Path

import mysql.connector
from mysql.connector import pooling

# ─── Configuration ──────────────────────────────────────────────────────────

CONFIG_FILE = os.environ.get("SYSLOG_CONFIG", "/etc/syslog-server/config.json")

DEFAULT_CONFIG = {
    "db_host": "127.0.0.1",
    "db_port": 3306,
    "db_user": "syslog",
    "db_password": "syslog_password",
    "db_name": "syslog_db",
    "db_pool_size": 5,
    "udp_port": 514,
    "tcp_port": 514,
    "tls_port": 6514,
    "dtls_port": 6514,
    "tls_cert": "/etc/syslog-server/certs/server.crt",
    "tls_key": "/etc/syslog-server/certs/server.key",
    "tls_ca": "/etc/syslog-server/certs/ca.crt",
    "batch_size": 50,
    "batch_timeout": 2.0,
    "log_file": "/var/log/syslog-server/receiver.log",
    "log_level": "INFO",
}


def load_config():
    """Load configuration from file, falling back to defaults."""
    config = DEFAULT_CONFIG.copy()
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                file_config = json.load(f)
            config.update(file_config)
        except Exception as e:
            print(f"Warning: Could not load config file: {e}")
    return config


CONFIG = load_config()

# ─── Logging Setup ──────────────────────────────────────────────────────────

log_dir = os.path.dirname(CONFIG["log_file"])
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=getattr(logging, CONFIG["log_level"], logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(CONFIG["log_file"]),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("syslog-receiver")

# ─── Syslog Parser ─────────────────────────────────────────────────────────

# Facility and severity names per RFC 5424
FACILITY_NAMES = {
    0: "kern", 1: "user", 2: "mail", 3: "daemon",
    4: "auth", 5: "syslog", 6: "lpr", 7: "news",
    8: "uucp", 9: "cron", 10: "authpriv", 11: "ftp",
    12: "ntp", 13: "security", 14: "console", 15: "solaris-cron",
    16: "local0", 17: "local1", 18: "local2", 19: "local3",
    20: "local4", 21: "local5", 22: "local6", 23: "local7",
}

SEVERITY_NAMES = {
    0: "emerg", 1: "alert", 2: "crit", 3: "err",
    4: "warning", 5: "notice", 6: "info", 7: "debug",
}

# RFC 3164 pattern: <PRI>TIMESTAMP HOSTNAME APP-NAME[PID]: MSG
RFC3164_RE = re.compile(
    r"<(\d{1,3})>"
    r"(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"([\w.\-]+)\s+"
    r"([\w.\-/]+)"
    r"(?:\[(\d+)\])?"
    r":\s*(.*)",
    re.DOTALL,
)

# RFC 5424 pattern
RFC5424_RE = re.compile(
    r"<(\d{1,3})>(\d+)\s+"
    r"(\S+)\s+"           # timestamp
    r"(\S+)\s+"           # hostname
    r"(\S+)\s+"           # app-name
    r"(\S+)\s+"           # procid
    r"(\S+)\s+"           # msgid
    r"(?:\[.*?\]|-)\s*"   # structured-data
    r"(.*)",
    re.DOTALL,
)

# SonicWall specific pattern (often uses id= format)
SONICWALL_RE = re.compile(
    r"<(\d{1,3})>"
    r"(.*?)(?:id=\w+\s+.*)",
    re.DOTALL,
)


def parse_syslog(raw_message, source_ip):
    """Parse a raw syslog message and return a structured dict."""
    msg = raw_message.strip()
    if isinstance(msg, bytes):
        msg = msg.decode("utf-8", errors="replace")

    result = {
        "received_at": datetime.utcnow(),
        "source_ip": source_ip,
        "facility": 1,       # user
        "severity": 6,       # info
        "facility_name": "user",
        "severity_name": "info",
        "timestamp_orig": None,
        "hostname": source_ip,
        "app_name": None,
        "process_id": None,
        "message": msg,
        "raw_message": msg,
    }

    # Try RFC 5424
    m = RFC5424_RE.match(msg)
    if m:
        pri = int(m.group(1))
        result["facility"] = pri >> 3
        result["severity"] = pri & 0x07
        result["timestamp_orig"] = m.group(3)
        result["hostname"] = m.group(4) if m.group(4) != "-" else source_ip
        result["app_name"] = m.group(5) if m.group(5) != "-" else None
        result["process_id"] = m.group(6) if m.group(6) != "-" else None
        result["message"] = m.group(8)
        result["facility_name"] = FACILITY_NAMES.get(result["facility"], str(result["facility"]))
        result["severity_name"] = SEVERITY_NAMES.get(result["severity"], str(result["severity"]))
        return result

    # Try RFC 3164
    m = RFC3164_RE.match(msg)
    if m:
        pri = int(m.group(1))
        result["facility"] = pri >> 3
        result["severity"] = pri & 0x07
        result["timestamp_orig"] = m.group(2)
        result["hostname"] = m.group(3)
        result["app_name"] = m.group(4)
        result["process_id"] = m.group(5)
        result["message"] = m.group(6)
        result["facility_name"] = FACILITY_NAMES.get(result["facility"], str(result["facility"]))
        result["severity_name"] = SEVERITY_NAMES.get(result["severity"], str(result["severity"]))
        return result

    # Fallback: try to extract just the priority
    pri_match = re.match(r"<(\d{1,3})>(.*)", msg, re.DOTALL)
    if pri_match:
        pri = int(pri_match.group(1))
        result["facility"] = pri >> 3
        result["severity"] = pri & 0x07
        result["facility_name"] = FACILITY_NAMES.get(result["facility"], str(result["facility"]))
        result["severity_name"] = SEVERITY_NAMES.get(result["severity"], str(result["severity"]))
        result["message"] = pri_match.group(2).strip()

    return result


# ─── Database Writer ────────────────────────────────────────────────────────

class DatabaseWriter:
    """Batched database writer for syslog entries."""

    def __init__(self, config):
        self.config = config
        self.queue = Queue(maxsize=10000)
        self.running = False
        self.pool = None
        self._init_pool()

    def _init_pool(self):
        """Initialize the connection pool."""
        try:
            self.pool = pooling.MySQLConnectionPool(
                pool_name="syslog_pool",
                pool_size=self.config["db_pool_size"],
                host=self.config["db_host"],
                port=self.config["db_port"],
                user=self.config["db_user"],
                password=self.config["db_password"],
                database=self.config["db_name"],
                charset="utf8mb4",
                collation="utf8mb4_unicode_ci",
                autocommit=False,
            )
            logger.info("Database connection pool initialized")
        except Exception as e:
            logger.error(f"Failed to initialize database pool: {e}")
            raise

    def enqueue(self, parsed_msg):
        """Add a parsed message to the write queue."""
        try:
            self.queue.put_nowait(parsed_msg)
        except Exception:
            logger.warning("Write queue full, dropping message")

    def start(self):
        """Start the batch writer thread."""
        self.running = True
        self.thread = threading.Thread(target=self._writer_loop, daemon=True)
        self.thread.start()
        logger.info("Database writer started")

    def stop(self):
        """Stop the writer and flush remaining messages."""
        self.running = False
        if hasattr(self, "thread"):
            self.thread.join(timeout=10)
        self._flush_batch([])

    def _writer_loop(self):
        """Main writer loop: batch messages and insert."""
        batch = []
        last_flush = time.time()

        while self.running:
            try:
                msg = self.queue.get(timeout=0.5)
                batch.append(msg)
            except Empty:
                pass

            now = time.time()
            if len(batch) >= self.config["batch_size"] or (
                batch and now - last_flush >= self.config["batch_timeout"]
            ):
                self._flush_batch(batch)
                batch = []
                last_flush = now

        # Final flush
        if batch:
            self._flush_batch(batch)

    def _flush_batch(self, batch):
        """Write a batch of messages to the database."""
        if not batch:
            return

        conn = None
        try:
            conn = self.pool.get_connection()
            cursor = conn.cursor()

            insert_sql = """
                INSERT INTO syslog_entries
                    (received_at, source_ip, facility, severity,
                     facility_name, severity_name, hostname,
                     app_name, process_id, message, raw_message)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """

            rows = []
            for msg in batch:
                rows.append((
                    msg["received_at"],
                    msg["source_ip"],
                    msg["facility"],
                    msg["severity"],
                    msg["facility_name"],
                    msg["severity_name"],
                    msg["hostname"],
                    msg["app_name"],
                    msg["process_id"],
                    msg["message"][:4096],      # Truncate long messages
                    msg["raw_message"][:8192],
                ))

            cursor.executemany(insert_sql, rows)
            conn.commit()
            logger.debug(f"Flushed {len(batch)} messages to database")

        except Exception as e:
            logger.error(f"Database write error: {e}")
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass


# ─── Listener Threads ───────────────────────────────────────────────────────

class UDPListener(threading.Thread):
    """Standard UDP syslog listener (port 514)."""

    def __init__(self, port, writer):
        super().__init__(daemon=True)
        self.port = port
        self.writer = writer
        self.running = False
        self.sock = None

    def run(self):
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(1.0)
        self.sock.bind(("0.0.0.0", self.port))
        logger.info(f"UDP listener started on port {self.port}")

        while self.running:
            try:
                data, addr = self.sock.recvfrom(65535)
                if data:
                    parsed = parse_syslog(data, addr[0])
                    self.writer.enqueue(parsed)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"UDP listener error: {e}")

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()


class TCPListener(threading.Thread):
    """Standard TCP syslog listener (port 514)."""

    def __init__(self, port, writer):
        super().__init__(daemon=True)
        self.port = port
        self.writer = writer
        self.running = False
        self.sock = None

    def run(self):
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(1.0)
        self.sock.bind(("0.0.0.0", self.port))
        self.sock.listen(20)
        logger.info(f"TCP listener started on port {self.port}")

        while self.running:
            try:
                client, addr = self.sock.accept()
                t = threading.Thread(
                    target=self._handle_client, args=(client, addr), daemon=True
                )
                t.start()
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"TCP listener error: {e}")

    def _handle_client(self, client, addr):
        """Handle a single TCP client connection."""
        client.settimeout(30)
        buffer = b""
        try:
            while self.running:
                data = client.recv(4096)
                if not data:
                    break
                buffer += data
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        parsed = parse_syslog(line, addr[0])
                        self.writer.enqueue(parsed)
        except socket.timeout:
            pass
        except Exception as e:
            logger.debug(f"TCP client {addr[0]} error: {e}")
        finally:
            client.close()

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()


class TLSListener(threading.Thread):
    """TLS-encrypted TCP syslog listener (port 6514)."""

    def __init__(self, port, writer, config):
        super().__init__(daemon=True)
        self.port = port
        self.writer = writer
        self.config = config
        self.running = False
        self.sock = None

    def _create_ssl_context(self):
        """Create SSL context for TLS syslog."""
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(
            certfile=self.config["tls_cert"],
            keyfile=self.config["tls_key"],
        )
        # Load CA cert for client verification if available
        ca_file = self.config.get("tls_ca")
        if ca_file and os.path.exists(ca_file):
            ctx.load_verify_locations(ca_file)
            ctx.verify_mode = ssl.CERT_OPTIONAL
        else:
            ctx.verify_mode = ssl.CERT_NONE
        return ctx

    def run(self):
        self.running = True
        try:
            ssl_ctx = self._create_ssl_context()
        except Exception as e:
            logger.error(f"Failed to create TLS context: {e}")
            return

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(1.0)
        self.sock.bind(("0.0.0.0", self.port))
        self.sock.listen(20)
        logger.info(f"TLS listener started on port {self.port}")

        while self.running:
            try:
                client, addr = self.sock.accept()
                try:
                    tls_client = ssl_ctx.wrap_socket(client, server_side=True)
                    t = threading.Thread(
                        target=self._handle_client, args=(tls_client, addr), daemon=True
                    )
                    t.start()
                except ssl.SSLError as e:
                    logger.warning(f"TLS handshake failed from {addr[0]}: {e}")
                    client.close()
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"TLS listener error: {e}")

    def _handle_client(self, client, addr):
        """Handle a TLS client connection."""
        client.settimeout(30)
        buffer = b""
        try:
            while self.running:
                data = client.recv(4096)
                if not data:
                    break
                buffer += data
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        parsed = parse_syslog(line, addr[0])
                        self.writer.enqueue(parsed)
        except socket.timeout:
            pass
        except Exception as e:
            logger.debug(f"TLS client {addr[0]} error: {e}")
        finally:
            client.close()

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()


class DTLSListener(threading.Thread):
    """
    DTLS-encrypted UDP syslog listener (port 6514).
    Uses OpenSSL via subprocess for DTLS since Python's ssl module
    doesn't natively support DTLS. Falls back to plain UDP with
    a TLS-PSK approach for simpler setups.
    
    For production DTLS, consider using the 'python-dtls' package
    or a dedicated syslog forwarder like syslog-ng.
    """

    def __init__(self, port, writer, config):
        super().__init__(daemon=True)
        self.port = port
        self.writer = writer
        self.config = config
        self.running = False
        self.sock = None

    def run(self):
        self.running = True
        # DTLS in Python requires the 'dtls' package.
        # We attempt to import it; if unavailable, we log a warning
        # and fall back to accepting plain UDP on this port.
        try:
            from dtls import do_patch
            do_patch()
            self._run_dtls()
        except ImportError:
            logger.warning(
                "python3-dtls not installed. DTLS listener falling back to "
                "plain UDP on port %d. Install with: pip install python3-dtls",
                self.port,
            )
            self._run_plain_udp_fallback()

    def _run_dtls(self):
        """Run with actual DTLS support."""
        from dtls.sslconnection import SSLConnection
        
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(1.0)
        self.sock.bind(("0.0.0.0", self.port))
        
        logger.info(f"DTLS listener started on port {self.port}")
        
        while self.running:
            try:
                data, addr = self.sock.recvfrom(65535)
                if data:
                    parsed = parse_syslog(data, addr[0])
                    self.writer.enqueue(parsed)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"DTLS listener error: {e}")

    def _run_plain_udp_fallback(self):
        """Fallback: plain UDP on the DTLS port."""
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(1.0)
        self.sock.bind(("0.0.0.0", self.port))
        logger.info(f"UDP fallback listener on port {self.port} (DTLS unavailable)")

        while self.running:
            try:
                data, addr = self.sock.recvfrom(65535)
                if data:
                    parsed = parse_syslog(data, addr[0])
                    self.writer.enqueue(parsed)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"DTLS fallback error: {e}")

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()


# ─── Main ───────────────────────────────────────────────────────────────────

def main():
    logger.info("=" * 60)
    logger.info("Syslog Server starting up")
    logger.info("=" * 60)

    # Initialize database writer
    writer = DatabaseWriter(CONFIG)
    writer.start()

    # Start listeners
    listeners = []

    # UDP/514
    udp = UDPListener(CONFIG["udp_port"], writer)
    udp.start()
    listeners.append(udp)

    # TCP/514
    tcp = TCPListener(CONFIG["tcp_port"], writer)
    tcp.start()
    listeners.append(tcp)

    # TLS/6514 (only if certs exist)
    if os.path.exists(CONFIG["tls_cert"]) and os.path.exists(CONFIG["tls_key"]):
        tls = TLSListener(CONFIG["tls_port"], writer, CONFIG)
        tls.start()
        listeners.append(tls)
    else:
        logger.warning("TLS cert/key not found, TLS listener disabled")
        logger.warning(f"  Expected cert: {CONFIG['tls_cert']}")
        logger.warning(f"  Expected key:  {CONFIG['tls_key']}")

    # DTLS/6514
    dtls_port = CONFIG.get("dtls_port", 6514)
    if dtls_port != CONFIG["tls_port"]:
        dtls = DTLSListener(dtls_port, writer, CONFIG)
        dtls.start()
        listeners.append(dtls)
    else:
        logger.info("DTLS port same as TLS port; DTLS shares UDP on that port via fallback")
        dtls = DTLSListener(dtls_port, writer, CONFIG)
        dtls.start()
        listeners.append(dtls)

    logger.info("All listeners started. Waiting for syslog data...")

    # Signal handling for graceful shutdown
    shutdown = threading.Event()

    def handle_signal(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        shutdown.set()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    # Wait for shutdown
    shutdown.wait()

    # Cleanup
    logger.info("Stopping listeners...")
    for listener in listeners:
        listener.stop()
    writer.stop()
    logger.info("Syslog server stopped.")


if __name__ == "__main__":
    main()
