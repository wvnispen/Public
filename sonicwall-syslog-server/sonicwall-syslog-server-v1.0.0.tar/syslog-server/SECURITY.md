# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability in the Sonicwall Syslog Server, please report it responsibly.

### How to Report

**Please do NOT open a public GitHub issue for security vulnerabilities.**

Instead, please report vulnerabilities by:

1. **Email**: Send a detailed description to the repository maintainer (see GitHub profile)
2. **GitHub Security Advisories**: Use the "Report a vulnerability" button under the Security tab of this repository

### What to Include

- A description of the vulnerability
- Steps to reproduce the issue
- The potential impact
- Any suggested fixes (if applicable)

### Response Timeline

- **Acknowledgment**: Within 48 hours of your report
- **Assessment**: Within 7 days we'll provide an initial assessment
- **Fix**: Critical vulnerabilities will be prioritized for the next patch release

### Security Best Practices for Deployment

When deploying this application, please ensure:

1. **Change all default passwords** immediately after installation
   - MariaDB root password
   - Syslog database user password
   - Web UI admin password

2. **Restrict network access**
   - Use UFW or iptables to limit which IPs can reach ports 514, 6514, and 8443
   - Place the web UI behind a reverse proxy with HTTPS (see README)

3. **Use TLS for syslog transport** whenever possible
   - Replace the self-signed certificates with proper CA-signed certificates for production
   - Distribute the CA certificate to all syslog clients

4. **Keep the system updated**
   ```bash
   sudo apt update && sudo apt upgrade
   pip install --upgrade -r requirements.txt
   ```

5. **Review MariaDB security**
   - Ensure the database is only listening on localhost (127.0.0.1)
   - Use strong passwords for all database accounts
   - Regularly review database user privileges

6. **Monitor the application logs**
   ```bash
   sudo journalctl -u syslog-receiver -f
   sudo journalctl -u syslog-web -f
   ```

7. **Back up regularly**
   ```bash
   mysqldump -u root -p syslog_db | gzip > syslog_backup_$(date +%Y%m%d).sql.gz
   ```

## Known Security Considerations

- The web UI uses session-based authentication with PBKDF2-SHA256 password hashing
- The web UI runs on HTTP by default — **always use a reverse proxy with HTTPS in production**
- The DTLS listener falls back to plain UDP if the `python3-dtls` package is not installed
- Database credentials are stored in `/etc/syslog-server/config.json` with mode 600
- TLS private keys are stored with mode 600 under the service user
