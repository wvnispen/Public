---
name: Feature Request
about: Suggest a new feature or improvement
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Problem / Motivation
A clear description of the problem this feature would solve.
Example: "I need to forward logs to a SIEM, but there's no way to..."

## Proposed Solution
A clear description of what you'd like to happen.

## Alternatives Considered
Any alternative solutions or workarounds you've considered.

## Device / Use Case
Which devices or scenarios does this relate to?
- [ ] SonicWall firewalls
- [ ] Other firewalls (specify: ___)
- [ ] Switches / Routers
- [ ] Linux servers
- [ ] Web UI
- [ ] Database / Storage
- [ ] API
- [ ] Other: ___

## Additional Context
Add any other context, mockups, or screenshots about the feature request here.
