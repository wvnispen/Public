## Description
Brief description of what this PR does.

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)
- [ ] Security fix

## Related Issues
Closes #(issue number)

## Changes Made
- 
- 
- 

## Testing Performed
- [ ] Syslog receiver starts without errors
- [ ] UDP syslog messages are received and stored
- [ ] TCP syslog messages are received and stored
- [ ] TLS syslog connections work
- [ ] Web UI loads and all pages render correctly
- [ ] Log search returns correct results
- [ ] Host management (add/edit/delete) works
- [ ] Tested on Ubuntu 22.04 LTS or 24.04 LTS
- [ ] No new warnings or errors in logs

## Screenshots (if applicable)

## Checklist
- [ ] My code follows the project's coding standards
- [ ] I have updated the documentation (if needed)
- [ ] I have added an entry to CHANGELOG.md
- [ ] I have tested my changes thoroughly
- [ ] My changes don't introduce new security vulnerabilities
