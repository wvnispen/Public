#!/usr/bin/env python3
"""
Proxmox VM Deployment Script with OVMF Firmware Support

This script automates the deployment of Proxmox VMs with custom OVMF firmware files.
It handles VM creation, disk import, and OVMF configuration.
"""

import os
import sys
import json
import subprocess
import shutil
from pathlib import Path
from typing import Dict, Any, Optional


class ProxmoxVMDeployer:
    """Handle Proxmox VM deployment with OVMF firmware support."""
    
    def __init__(self):
        self.vm_name: Optional[str] = None
        self.vm_id: Optional[int] = None
        self.storage_name: Optional[str] = None
        self.node_name: Optional[str] = None
        self.qcow2_path: Optional[Path] = None
        self.ovmf_code_path: Optional[Path] = None
        self.ovmf_vars_path: Optional[Path] = None
        self.vm_config: Optional[Dict[str, Any]] = None
        
    def get_node_name(self) -> str:
        """Get the Proxmox node name."""
        try:
            result = subprocess.run(
                ['hostname'],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            print(f"Error getting node name: {e}")
            sys.exit(1)
    
    def validate_files(self, qcow2: str, ovmf_code: str, ovmf_vars: str) -> bool:
        """Validate that all required files exist."""
        files = {
            'QCOW2 disk image': qcow2,
            'OVMF_CODE file': ovmf_code,
            'OVMF_VARS file': ovmf_vars
        }
        
        all_valid = True
        for file_type, file_path in files.items():
            if not os.path.exists(file_path):
                print(f"❌ Error: {file_type} not found: {file_path}")
                all_valid = False
            else:
                print(f"✓ Found {file_type}: {file_path}")
        
        return all_valid
    
    def prompt_user_inputs(self):
        """Prompt user for VM configuration parameters."""
        print("\n" + "="*60)
        print("Proxmox VM Deployment - Configuration")
        print("="*60)
        
        # VM Name
        while True:
            self.vm_name = input("\nEnter VM name: ").strip()
            if self.vm_name:
                break
            print("VM name cannot be empty!")
        
        # VM ID
        while True:
            try:
                vm_id_input = input("Enter VM ID (e.g., 100): ").strip()
                self.vm_id = int(vm_id_input)
                if self.vm_id > 0:
                    break
                print("VM ID must be a positive number!")
            except ValueError:
                print("Invalid input! Please enter a numeric VM ID.")
        
        # Storage Name
        while True:
            self.storage_name = input("Enter storage name (e.g., local-lvm): ").strip()
            if self.storage_name:
                break
            print("Storage name cannot be empty!")
        
        print("\n" + "-"*60)
        print("Advanced VM Configuration")
        print("-"*60)
        
        # Memory
        memory = self._get_input_with_default(
            "Enter RAM in MB",
            "4096",
            int
        )
        
        # CPU Cores
        cores = self._get_input_with_default(
            "Enter number of CPU cores",
            "2",
            int
        )
        
        # CPU Sockets
        sockets = self._get_input_with_default(
            "Enter number of CPU sockets",
            "1",
            int
        )
        
        # CPU Type
        cpu_type = self._get_input_with_default(
            "Enter CPU type (host/x86-64-v2-AES/kvm64)",
            "host",
            str
        )
        
        # OS Type
        print("\nOS Types: l26 (Linux 2.6+), win11 (Windows 11), win10 (Windows 10), other")
        ostype = self._get_input_with_default(
            "Enter OS type",
            "l26",
            str
        )
        
        # SCSI Controller
        scsihw = self._get_input_with_default(
            "Enter SCSI controller (virtio-scsi-pci/virtio-scsi-single)",
            "virtio-scsi-pci",
            str
        )
        
        # Network Bridge
        bridge = self._get_input_with_default(
            "Enter network bridge",
            "vmbr0",
            str
        )
        
        # QEMU Guest Agent
        agent_input = self._get_input_with_default(
            "Enable QEMU guest agent? (yes/no)",
            "yes",
            str
        )
        agent = "1" if agent_input.lower() in ['yes', 'y', '1'] else "0"
        
        # Machine Type
        machine = self._get_input_with_default(
            "Enter machine type (q35/pc)",
            "q35",
            str
        )
        
        # NUMA
        numa = self._get_input_with_default(
            "Enable NUMA (0=disabled, 1=enabled)",
            "0",
            str
        )
        
        # Build configuration dictionary
        # Note: efidisk0 will be added separately after VM creation
        self.vm_config = {
            "bios": "seabios",
            "cores": cores,
            "cpu": cpu_type,
            "ide2": "none,media=cdrom",
            "machine": machine,
            "memory": memory,
            "name": self.vm_name,
            "net0": f"virtio,bridge={bridge}",
            "net1": f"virtio,bridge={bridge}",
            "numa": numa,
            "ostype": ostype,
            "scsihw": scsihw,
            "serial0": "socket",
            "sockets": sockets
        }
        
        # Add agent only if enabled
        if agent == "1":
            self.vm_config["agent"] = agent
        
        # Display configuration summary
        print("\n" + "="*60)
        print("Configuration Summary:")
        print("="*60)
        print(f"VM Name:        {self.vm_name}")
        print(f"VM ID:          {self.vm_id}")
        print(f"Storage:        {self.storage_name}")
        print(f"Memory:         {memory} MB")
        print(f"CPU:            {cores} cores, {sockets} socket(s), type: {cpu_type}")
        print(f"OS Type:        {ostype}")
        print(f"SCSI HW:        {scsihw}")
        print(f"Network 0:      {bridge} (virtio)")
        print(f"Network 1:      {bridge} (virtio, no firewall)")
        print(f"Guest Agent:    {'Enabled' if agent == '1' else 'Disabled'}")
        print(f"Machine:        {machine}")
        print(f"NUMA:           {'Enabled' if numa == '1' else 'Disabled'}")
        print(f"BIOS:           SeaBIOS (with custom OVMF firmware)")
        print(f"Serial:         Enabled (socket)")
        print(f"EFI Disk:       Will be created (1M, pre-enrolled-keys)")
        print(f"IDE2:           CD-ROM (none)")
        print("="*60)
        
        # Save configuration to file for reference
        config_file = Path(f'/tmp/vm_{self.vm_id}_config.json')
        with open(config_file, 'w') as f:
            json.dump(self.vm_config, f, indent=2)
        print(f"\n💾 Configuration saved to: {config_file}")
        
        confirm = input("\nProceed with deployment? (yes/no): ").strip().lower()
        if confirm not in ['yes', 'y']:
            print("Deployment cancelled.")
            sys.exit(0)
    
    def _get_input_with_default(self, prompt: str, default: str, value_type):
        """Get user input with a default value."""
        user_input = input(f"{prompt} [{default}]: ").strip()
        if not user_input:
            return value_type(default)
        try:
            return value_type(user_input)
        except ValueError:
            print(f"Invalid input, using default: {default}")
            return value_type(default)
    
    def create_vm(self) -> bool:
        """Create the Proxmox VM based on configuration."""
        print("\n📝 Creating Proxmox VM...")
        
        # Build the qm create command
        cmd = ['qm', 'create', str(self.vm_id)]
        
        # Add name
        cmd.extend(['--name', self.vm_name])
        
        # Parse config and add parameters
        for key, value in self.vm_config.items():
            if key in ['args']:  # Skip args as we'll add it manually later
                continue
            
            if isinstance(value, bool):
                value = '1' if value else '0'
            elif isinstance(value, (dict, list)):
                value = json.dumps(value)
            else:
                value = str(value)
            
            cmd.append(f'--{key}')
            cmd.append(value)
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            print(f"✓ VM {self.vm_id} created successfully")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error creating VM: {e}")
            print(f"STDOUT: {e.stdout}")
            print(f"STDERR: {e.stderr}")
            return False
    
    def add_efidisk(self) -> bool:
        """Add EFI disk to the VM after creation."""
        print(f"\n💾 Adding EFI disk...")
        
        cmd = [
            'qm', 'set',
            str(self.vm_id),
            '--efidisk0',
            f"{self.storage_name}:1,efitype=4m,pre-enrolled-keys=1"
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            print(f"✓ EFI disk added (1M, pre-enrolled-keys)")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error adding EFI disk: {e}")
            print(f"STDERR: {e.stderr}")
            return False
    
    def import_disk(self) -> bool:
        """Import the QCOW2 disk image to the VM."""
        print(f"\n💾 Importing disk image to storage '{self.storage_name}'...")
        
        cmd = [
            'qm', 'importdisk',
            str(self.vm_id),
            str(self.qcow2_path),
            self.storage_name
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            print("✓ Disk imported successfully")
            output = result.stdout.strip()
            print(f"  Output: {output}")
            
            # Parse output to find the disk name
            # Output format is typically: "Successfully imported disk as 'unused0:storage:vm-XXX-disk-1'"
            # or "Successfully imported disk as 'storage:vm-XXX-disk-1'"
            if 'unused0' in output.lower() or 'unused' in output.lower():
                print("  Note: Disk imported as unused, will be attached in next step")
            
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error importing disk: {e}")
            print(f"STDERR: {e.stderr}")
            return False
    
    def attach_disk_and_set_boot(self) -> bool:
        """Attach the imported disk to virtio0 and configure boot order."""
        print(f"\n🔗 Attaching imported disk to VM and configuring boot...")
        
        # After qm importdisk, the disk is created as "unused0"
        # We need to attach it to virtio0
        cmd_attach = [
            'qm', 'set',
            str(self.vm_id),
            '--virtio0',
            'unused0:0,iothread=1'
        ]
        
        try:
            result = subprocess.run(cmd_attach, capture_output=True, text=True, check=True)
            print(f"✓ Imported disk attached to virtio0 with iothread")
        except subprocess.CalledProcessError as e:
            print(f"❌ Error attaching disk: {e}")
            print(f"STDERR: {e.stderr}")
            print(f"\nTrying alternative method...")
            
            # Alternative: specify full disk path
            cmd_attach_alt = [
                'qm', 'set',
                str(self.vm_id),
                '--virtio0',
                f"{self.storage_name}:vm-{self.vm_id}-disk-1,iothread=1"
            ]
            
            try:
                result = subprocess.run(cmd_attach_alt, capture_output=True, text=True, check=True)
                print(f"✓ Disk attached using full path")
            except subprocess.CalledProcessError as e2:
                print(f"❌ Alternative method also failed: {e2}")
                print(f"STDERR: {e2.stderr}")
                return False
        
        # Set boot order to virtio0
        cmd_boot = [
            'qm', 'set',
            str(self.vm_id),
            '--boot',
            'order=virtio0'
        ]
        
        try:
            result = subprocess.run(cmd_boot, capture_output=True, text=True, check=True)
            print(f"✓ Boot order set to virtio0")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Error setting boot order: {e}")
            print(f"STDERR: {e.stderr}")
            return False
    
    def copy_ovmf_files(self) -> bool:
        """Copy OVMF firmware files to /usr/share/pve-edk2-firmware/{vm_id}/."""
        print("\n📋 Copying OVMF firmware files...")
        
        # Create VM-specific directory under pve-edk2-firmware
        ovmf_dir = Path(f'/usr/share/pve-edk2-firmware/{self.vm_id}')
        
        # Create directory if it doesn't exist
        try:
            ovmf_dir.mkdir(parents=True, exist_ok=True)
            print(f"✓ Created directory: {ovmf_dir}")
        except PermissionError:
            print("❌ Error: Permission denied. Please run this script with sudo.")
            return False
        
        # Copy OVMF_CODE file
        try:
            dest_code = ovmf_dir / 'OVMF_CODE.sw.fd'
            shutil.copy2(self.ovmf_code_path, dest_code)
            print(f"✓ Copied {self.ovmf_code_path.name} to {dest_code}")
        except Exception as e:
            print(f"❌ Error copying OVMF_CODE file: {e}")
            return False
        
        # Copy OVMF_VARS file
        try:
            dest_vars = ovmf_dir / 'OVMF_VARS.sw.fd'
            shutil.copy2(self.ovmf_vars_path, dest_vars)
            print(f"✓ Copied {self.ovmf_vars_path.name} to {dest_vars}")
        except Exception as e:
            print(f"❌ Error copying OVMF_VARS file: {e}")
            return False
        
        return True
    
    def add_args_to_config(self) -> bool:
        """Add OVMF args line to the VM configuration file."""
        print("\n⚙️  Adding OVMF args to VM configuration...")
        
        config_file = Path(f'/etc/pve/nodes/{self.node_name}/qemu-server/{self.vm_id}.conf')
        
        if not config_file.exists():
            print(f"❌ Error: Config file not found: {config_file}")
            return False
        
        # Use VM ID-specific path matching the working config structure
        args_line = f"args: -drive 'if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/pve-edk2-firmware/{self.vm_id}/OVMF_CODE.sw.fd' -drive 'if=pflash,unit=1,format=raw,file=/usr/share/pve-edk2-firmware/{self.vm_id}/OVMF_VARS.sw.fd'\n"
        
        try:
            # Read existing config
            with open(config_file, 'r') as f:
                lines = f.readlines()
            
            # Check if args already exists
            has_args = any(line.strip().startswith('args:') for line in lines)
            
            if has_args:
                print("⚠️  Warning: 'args' line already exists in config. Replacing it...")
                lines = [line for line in lines if not line.strip().startswith('args:')]
            
            # Add args line at the top
            lines.insert(0, args_line)
            
            # Write back to file
            with open(config_file, 'w') as f:
                f.writelines(lines)
            
            print(f"✓ Added OVMF args to {config_file}")
            print(f"  Path: /usr/share/pve-edk2-firmware/{self.vm_id}/")
            return True
            
        except PermissionError:
            print("❌ Error: Permission denied. Please run this script with sudo.")
            return False
        except Exception as e:
            print(f"❌ Error modifying config file: {e}")
            return False
    
    def display_banner(self):
        """Display startup banner."""
        banner = """
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║          SonicWall NSx Deployment Script for Proxmox                    ║
║                                                                          ║
║          Created by Wynand van Nispen (wvannipen@sonicwall.com)        ║
║          Version: 2.5 (Current Version)                                 ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝
        """
        print(banner)
    
    def deploy(self, qcow2: str, ovmf_code: str, ovmf_vars: str):
        """Main deployment workflow."""
        # Display banner
        self.display_banner()
        
        print("\n" + "="*60)
        print("Proxmox VM Deployment Script with OVMF Support")
        print("="*60)
        
        # Validate files
        if not self.validate_files(qcow2, ovmf_code, ovmf_vars):
            print("\n❌ File validation failed. Exiting.")
            sys.exit(1)
        
        # Store file paths
        self.qcow2_path = Path(qcow2)
        self.ovmf_code_path = Path(ovmf_code)
        self.ovmf_vars_path = Path(ovmf_vars)
        
        # Get node name
        self.node_name = self.get_node_name()
        print(f"\n✓ Proxmox node: {self.node_name}")
        
        # Get user inputs and build configuration
        self.prompt_user_inputs()
        
        # Check if running as root
        if os.geteuid() != 0:
            print("\n⚠️  Warning: This script requires root privileges.")
            print("Please run with sudo or as root user.")
            sys.exit(1)
        
        # Deployment steps
        print("\n" + "="*60)
        print("Starting Deployment...")
        print("="*60)
        
        # Step 1: Create VM
        if not self.create_vm():
            print("\n❌ VM creation failed. Aborting deployment.")
            sys.exit(1)
        
        # Step 2: Add EFI disk
        if not self.add_efidisk():
            print("\n❌ EFI disk creation failed. Aborting deployment.")
            sys.exit(1)
        
        # Step 3: Import disk
        if not self.import_disk():
            print("\n❌ Disk import failed. Aborting deployment.")
            sys.exit(1)
        
        # Step 4: Attach disk and set boot order
        if not self.attach_disk_and_set_boot():
            print("\n❌ Disk attachment failed. Aborting deployment.")
            sys.exit(1)
        
        # Step 5: Copy OVMF files
        if not self.copy_ovmf_files():
            print("\n❌ OVMF file copy failed. Aborting deployment.")
            sys.exit(1)
        
        # Step 6: Add args to config
        if not self.add_args_to_config():
            print("\n❌ Config modification failed. Aborting deployment.")
            sys.exit(1)
        
        # Success!
        print("\n" + "="*60)
        print("✅ VM Deployment Completed Successfully!")
        print("="*60)
        print(f"VM Name: {self.vm_name}")
        print(f"VM ID: {self.vm_id}")
        print(f"Node: {self.node_name}")
        print(f"Storage: {self.storage_name}")
        print(f"Disk: Attached to virtio0 (with iothread) and configured as boot device")
        print(f"Network: Two adapters on {self.storage_name}")
        print(f"  - net0: Standard virtio adapter")
        print(f"  - net1: Virtio adapter (no firewall)")
        print(f"Serial: Enabled for console access")
        print(f"OVMF: Firmware files in /usr/share/pve-edk2-firmware/{self.vm_id}/")
        print(f"\nConfiguration file saved: /tmp/vm_{self.vm_id}_config.json")
        print("\nYour VM is ready to start:")
        print(f"  qm start {self.vm_id}")
        print(f"\nAccess the serial console:")
        print(f"  qm terminal {self.vm_id}")
        print("="*60)


def main():
    """Main entry point."""
    if len(sys.argv) != 4:
        print("Usage: python3 proxmox_vm_deploy.py <qcow2_file> <ovmf_code_file> <ovmf_vars_file>")
        print("\nExample:")
        print("  sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd")
        print("\nThe script will prompt you for:")
        print("  - VM name")
        print("  - VM ID (machine ID number)")
        print("  - Storage name")
        print("  - VM configuration parameters (memory, CPU, etc.)")
        sys.exit(1)
    
    qcow2_file = sys.argv[1]
    ovmf_code = sys.argv[2]
    ovmf_vars = sys.argv[3]
    
    deployer = ProxmoxVMDeployer()
    deployer.deploy(qcow2_file, ovmf_code, ovmf_vars)


if __name__ == '__main__':
    main()
