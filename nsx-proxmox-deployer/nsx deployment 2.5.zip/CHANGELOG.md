# Changelog - Proxmox VM Deployment Script

## Version 2.2 - Current

### Configuration Matching Updates
✅ **Updated to match working VM configuration format**
   - Changed from `scsi0` to `virtio0` for main disk
   - Added `iothread=1` to virtio0 for better performance
   - Changed BIOS from `ovmf` to `seabios`
   - Updated efidisk0: `pre-enrolled-keys=1` (was 0)
   - Added `ide2: none,media=cdrom`
   - Added `numa` configuration option
   - Removed `vga: serial0` (using serial0 socket only)
   - Removed `firewall=1` from network config

### Configuration Details
```conf
args: OVMF paths at top of config
bios: seabios (not ovmf)
boot: order=virtio0 (not scsi0)
efidisk0: pre-enrolled-keys=1,size=4M
ide2: none,media=cdrom
numa: 0 (configurable)
serial0: socket
virtio0: with iothread=1
```

### Why These Changes
- **virtio0**: Better performance than SCSI for most workloads
- **iothread**: Improved I/O performance for VirtIO devices
- **seabios**: More compatible BIOS option
- **pre-enrolled-keys=1**: Secure boot support enabled
- **ide2**: Standard CD-ROM device placeholder
- **numa=0**: NUMA disabled for single-socket configurations

---

## Version 2.1

### New Features
✅ **Serial Console Adapter** - Automatically configured for all VMs
   - `serial0: socket` configuration added
   - `vga: serial0` set as display
   - Access via `qm terminal <vm_id>`
   - Exit with Ctrl+O

✅ **Automatic Disk Attachment** - No manual steps needed!
   - Disk automatically attached to scsi0 after import
   - Boot order automatically set to scsi0
   - VM is ready to start immediately after deployment

✅ **Streamlined Post-Deployment** - Just one command to start!
   - Old: 3 manual commands needed (attach disk, set boot, start)
   - New: 1 command (`qm start <vm_id>`)

### Benefits
- **Faster deployment** - Reduced manual steps from 3 to 0
- **Better troubleshooting** - Serial console provides boot output
- **Headless friendly** - No need for VGA/display for initial setup
- **Less error-prone** - Automatic configuration eliminates manual mistakes

### Technical Details

#### Serial Console Configuration
```
serial0: socket
vga: serial0
```

#### Automatic Disk Operations
1. Import disk with `qm importdisk`
2. Attach to scsi0: `qm set <id> --scsi0 <storage>:vm-<id>-disk-0`
3. Set boot order: `qm set <id> --boot order=scsi0`

All three operations now happen automatically during deployment!

---

## Version 2.0

### Major Changes
- Removed JSON configuration file requirement
- Interactive configuration builder
- Accepts only 3 files instead of 4
- Auto-generates VM configuration
- Saves configuration to `/tmp/vm_{id}_config.json`

### Features
- Interactive prompts for all VM parameters
- Sensible defaults for quick deployment
- Configuration validation
- Summary display before deployment

---

## Version 1.0 - Initial Release

### Features
- VM creation from JSON config
- QCOW2 disk import
- OVMF firmware installation
- Automatic OVMF args configuration
- Required 4 files (qcow2, json, 2x OVMF files)

---

## Migration Guide

### From v1.0 to v2.x
**Before (v1.0):**
```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 config.json OVMF_CODE.fd OVMF_VARS.fd
```

**After (v2.x):**
```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.fd OVMF_VARS.fd
# Then answer interactive prompts
```

### From v2.0 to v2.1
No changes to command syntax!
Just fewer manual post-deployment steps:

**Before (v2.0):**
```bash
# After script completes:
qm set 100 --scsi0 local-lvm:vm-100-disk-0
qm set 100 --boot order=scsi0
qm start 100
```

**After (v2.1):**
```bash
# After script completes:
qm start 100  # That's it!
```

---

## Upcoming Features (Planned)

- [ ] Cloud-init support
- [ ] Multiple disk support
- [ ] Custom network VLAN tags in config
- [ ] Snapshot creation after deployment
- [ ] Backup integration
- [ ] Template creation option
- [ ] Batch deployment from CSV
- [ ] Pre-deployment validation checks
- [ ] Rollback on failure

---

## Current Deployment Flow

```
1. Validate files (qcow2, 2x OVMF)
2. Get Proxmox node name
3. Prompt user for configuration
4. Save config to JSON (for reference)
5. Create VM with all settings (including serial)
6. Import disk image
7. Attach disk to scsi0 ← NEW in v2.1
8. Set boot order to scsi0 ← NEW in v2.1
9. Copy OVMF files to /usr/share/OVMF/
10. Add OVMF args to VM config
11. ✅ VM ready to start!
```

---

## Version Comparison

| Feature | v1.0 | v2.0 | v2.1 | v2.2 |
|---------|------|------|------|------|
| JSON file required | Yes | No | No | No |
| Interactive config | No | Yes | Yes | Yes |
| Number of input files | 4 | 3 | 3 | 3 |
| Serial console | No | No | **Yes** | **Yes** |
| Auto disk attach | No | No | **Yes** | **Yes** |
| Auto boot config | No | No | **Yes** | **Yes** |
| Config saved to file | No | Yes | Yes | Yes |
| Manual post-deploy steps | 0 | 3 | **0** | **0** |
| Disk interface | - | scsi0 | scsi0 | **virtio0** |
| IOthread support | No | No | No | **Yes** |
| BIOS type | - | ovmf | ovmf | **seabios** |
| NUMA config | No | No | No | **Yes** |
| IDE CD-ROM | No | No | No | **Yes** |
| Pre-enrolled keys | - | No (0) | No (0) | **Yes (1)** |
