# Quick Reference - Proxmox VM Deploy v2.5

## 🚀 One-Line Deploy
```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd
```

## ✅ What Gets Created

```
VM Configuration:
├── BIOS: seabios (with OVMF firmware via args)
├── Disk 0: EFI partition (1M, pre-enrolled-keys)
├── Disk 1: Your imported qcow2 (virtio0, iothread)
├── NIC 0: virtio on vmbr0
├── NIC 1: virtio on vmbr0 (no firewall)
├── Serial: socket console
└── Boot: virtio0

Files Created:
├── /usr/share/pve-edk2-firmware/{vm_id}/OVMF_CODE.sw.fd
├── /usr/share/pve-edk2-firmware/{vm_id}/OVMF_VARS.sw.fd
├── /etc/pve/nodes/{node}/qemu-server/{vm_id}.conf
└── /tmp/vm_{vm_id}_config.json
```

## 🔧 Post-Deployment Commands

```bash
# Start VM
qm start {vm_id}

# Access console
qm terminal {vm_id}
# Exit with Ctrl+O

# Check config
qm config {vm_id}

# Check status
qm status {vm_id}

# View disks
qm disk list {vm_id}
```

## 📋 Verify Deployment

```bash
# Check disk attached
qm config {vm_id} | grep virtio0
# Should show: virtio0: storage:vm-{id}-disk-1,iothread=1

# Check both NICs
qm config {vm_id} | grep net
# Should show: net0 and net1

# Check boot order
qm config {vm_id} | grep boot
# Should show: boot: order=virtio0

# Check OVMF files
ls /usr/share/pve-edk2-firmware/{vm_id}/
# Should show: OVMF_CODE.sw.fd and OVMF_VARS.sw.fd
```

## 🐛 Quick Fixes

### Disk not attached?
```bash
qm set {vm_id} --virtio0 unused0:0,iothread=1
qm set {vm_id} --boot order=virtio0
```

### Second NIC missing?
```bash
qm set {vm_id} --net1 virtio,bridge=vmbr0
```

### Boot order wrong?
```bash
qm set {vm_id} --boot order=virtio0
```

### Can't find OVMF files?
```bash
ls /usr/share/pve-edk2-firmware/{vm_id}/
# If empty, files weren't copied - check permissions
```

## 📊 Expected Final Config

```conf
args: -drive 'if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_CODE.sw.fd' ...
bios: seabios
boot: order=virtio0
efidisk0: storage:vm-{id}-disk-0,efitype=4m,pre-enrolled-keys=1,size=1M
net0: virtio={mac},bridge=vmbr0
net1: virtio={mac},bridge=vmbr0
serial0: socket
virtio0: storage:vm-{id}-disk-1,iothread=1,size={size}M
```

## ⚡ Key Features

- ✅ Two network adapters (both on vmbr0)
- ✅ VirtIO disk with iothread enabled
- ✅ UEFI boot via custom OVMF firmware
- ✅ Serial console access
- ✅ 1M EFI disk with pre-enrolled keys
- ✅ Automatic disk attachment from import
- ✅ Boot order automatically configured

## 📞 Need Help?

See detailed docs:
- README.md - Full documentation
- FINAL_FIXES_v2.5.md - Latest changes
- BOOT_ERROR_FIX.md - Boot troubleshooting
- CONFIG_COMPARISON.md - Config details

## 🎯 Success Checklist

- [ ] Script completed without errors
- [ ] Two NICs visible in config
- [ ] virtio0 shows iothread=1
- [ ] boot order is virtio0
- [ ] OVMF files exist in pve-edk2-firmware/{vm_id}/
- [ ] VM starts: `qm start {vm_id}`
- [ ] OS boots successfully
- [ ] Serial console accessible

## 💡 Pro Tips

1. **Always run with sudo** - Script needs root access
2. **Use descriptive VM names** - Easier to manage
3. **Organize VM IDs** - Use ranges (100-199, 200-299, etc.)
4. **Check storage space** - Before importing large disks
5. **Test serial console** - `qm terminal {vm_id}` after start
6. **Save config** - Found in `/tmp/vm_{id}_config.json`

## 🔥 Common Mistakes

❌ Not running with sudo  
✅ `sudo python3 proxmox_vm_deploy.py ...`

❌ Wrong file order  
✅ qcow2 first, then two OVMF files

❌ VM ID already exists  
✅ Use unique ID or delete old VM

❌ Insufficient storage space  
✅ Check with `pvesm status`

❌ QCOW2 not UEFI-bootable  
✅ Use UEFI-compatible images

---

**Version**: 2.5  
**Last Updated**: 2024  
**Status**: Production Ready ✅
