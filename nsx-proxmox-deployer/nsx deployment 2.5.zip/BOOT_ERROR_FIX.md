# Boot Error Fix - "Failed to load HostBoot UEFI Misc Device"

## Error Analysis

The error you encountered:
```
Bd>Dxe: failed to load HostB0001 "UEFI Misc Device" from PciRoot(0x0)/Pci(0x1E,0x
0)/Pci(0x1,0x0)/Pci(0x0,0x0): Not Found
Bd>Dxe: No bootable option or device was found.
Bd>Dxe: Press any key to enter the Boot Manager Menu.
```

## Root Cause

This error occurs when:
1. The EFI system can't find a bootable device
2. The OVMF firmware is looking for boot options but finds none
3. The disk might not be properly attached or recognized as bootable

## What Was Fixed in v2.4

### 1. EFI Disk Creation Order
**Problem**: EFI disk was being created during `qm create` which could cause timing issues.

**Solution**: Now EFI disk is created AFTER VM creation as a separate step:
```bash
qm create {id} [options...]
qm set {id} --efidisk0 {storage}:1,efitype=4m,pre-enrolled-keys=1
```

This ensures proper disk numbering and initialization.

### 2. Deployment Order
```
Old Order:
1. Create VM (with efidisk0)
2. Import disk
3. Attach disk
4. Copy OVMF
5. Add args

New Order:
1. Create VM (without efidisk0)
2. Add EFI disk separately
3. Import main disk
4. Attach disk to virtio0
5. Copy OVMF files
6. Add args line
```

### 3. Configuration
The VM now matches your working configuration:
- `bios: seabios` (not ovmf)
- Custom OVMF firmware via args line
- EFI disk with pre-enrolled keys
- VirtIO disk with iothread
- Serial console

## Expected Final Configuration

```conf
args: -drive 'if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_CODE.sw.fd' -drive 'if=pflash,unit=1,format=raw,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_VARS.sw.fd'
bios: seabios
boot: order=virtio0
cores: 2
cpu: x86-64-v2-AES
efidisk0: {storage}:vm-{id}-disk-0,efitype=4m,pre-enrolled-keys=1,size=1M
ide2: none,media=cdrom
machine: q35
memory: 4096
name: {vm_name}
net0: virtio={mac},bridge=vmbr0
numa: 0
ostype: l26
scsihw: virtio-scsi-single
serial0: socket
sockets: 1
virtio0: {storage}:vm-{id}-disk-1,iothread=1,size={size}M
```

## Disk Layout

After deployment, you should have:
- **disk-0**: EFI System Partition (1M)
- **disk-1**: Main OS disk (imported from qcow2)

## Verification Steps

### 1. Check VM Configuration
```bash
qm config {vm_id}
```

Look for:
- ✅ `args:` line with correct OVMF paths
- ✅ `bios: seabios`
- ✅ `boot: order=virtio0`
- ✅ `efidisk0:` present with size=1M
- ✅ `virtio0:` attached with iothread=1

### 2. Check OVMF Files
```bash
ls -lh /usr/share/pve-edk2-firmware/{vm_id}/
```

Should show:
```
OVMF_CODE.sw.fd
OVMF_VARS.sw.fd
```

### 3. Check Disk Attachments
```bash
qm disk list {vm_id}
```

Should show:
```
efidisk0: ...vm-{id}-disk-0... (1M)
virtio0: ...vm-{id}-disk-1... (main disk size)
```

### 4. Verify Boot Order
```bash
qm config {vm_id} | grep boot
```

Should show:
```
boot: order=virtio0
```

## If Boot Error Still Occurs

### Option 1: Check QCOW2 Image Compatibility
Your QCOW2 image must be UEFI-bootable. Verify:
```bash
# On the source system where qcow2 was created
virt-inspector -a disk.qcow2 | grep firmware
```

Should show UEFI support.

### Option 2: Verify EFI Partition in Disk
The imported disk must have an EFI System Partition:
```bash
# After VM boots to EFI shell, check partitions
# In serial console (qm terminal {id}):
fs0:
ls
```

Should see `EFI/` directory.

### Option 3: Manual Boot Configuration
If the disk has EFI files but won't boot automatically:

1. Access serial console:
```bash
qm terminal {vm_id}
```

2. At EFI shell, navigate to boot file:
```
fs0:
cd EFI\BOOT
bootx64.efi
```

3. Or try:
```
fs0:
cd EFI\ubuntu  (or your distro name)
grubx64.efi
```

### Option 4: Check for SecureBoot Issues
If you're using pre-enrolled keys but your image isn't signed:

Edit the VM config and change:
```bash
qm set {vm_id} --efidisk0 {storage}:vm-{id}-disk-0,efitype=4m,pre-enrolled-keys=0
```

This disables Secure Boot.

## Common Issues and Solutions

### Issue: "No bootable device found"
**Cause**: Disk not properly attached or boot order incorrect
**Fix**:
```bash
qm set {vm_id} --virtio0 {storage}:vm-{id}-disk-1,iothread=1
qm set {vm_id} --boot order=virtio0
```

### Issue: "OVMF firmware not loading"
**Cause**: OVMF files not in correct location
**Fix**:
```bash
ls /usr/share/pve-edk2-firmware/{vm_id}/
# Should show both OVMF_CODE.sw.fd and OVMF_VARS.sw.fd
# If not, copy them manually
```

### Issue: "EFI partition not found"
**Cause**: QCOW2 image doesn't have EFI boot setup
**Fix**: Use a UEFI-compatible image or:
```bash
# Convert legacy BIOS image to UEFI (on source system)
virt-install --import --disk path=disk.qcow2 --boot uefi
```

## Testing with Serial Console

Access the serial console during boot:
```bash
qm terminal {vm_id}
```

You should see:
1. OVMF firmware initialization
2. UEFI logo/banner
3. Boot device detection
4. GRUB menu (if Linux)
5. OS boot

If you see the EFI Shell instead, the boot device isn't being recognized.

## Alternative: Force BIOS Boot (Not Recommended)

If you absolutely must use legacy BIOS:
```bash
qm set {vm_id} --bios seabios
# Remove args line from config file manually
# Remove efidisk0
qm set {vm_id} --delete efidisk0
```

But this defeats the purpose of using custom OVMF firmware.

## Debug Mode

Enable OVMF debug output by editing the args line:
```conf
args: -drive 'if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_CODE.sw.fd' -drive 'if=pflash,unit=1,format=raw,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_VARS.sw.fd' -debugcon file:/tmp/ovmf-debug.log -global isa-debugcon.iobase=0x402
```

Then check:
```bash
cat /tmp/ovmf-debug.log
```

## Success Indicators

When everything works correctly, you should:
1. ✅ See OVMF logo/banner during boot
2. ✅ Boot directly to your OS (no EFI shell)
3. ✅ Serial console shows boot output
4. ✅ No "device not found" errors

## Updated Script Features (v2.4)

1. **Separate EFI disk creation** - Ensures proper initialization
2. **Correct disk numbering** - disk-0 for EFI, disk-1 for main
3. **Proper creation order** - VM → EFI → Import → Attach → OVMF → Args
4. **Matches working config exactly** - All settings from your VM 1009

## Next Steps

1. Delete the problematic VM:
```bash
qm stop {vm_id}
qm destroy {vm_id}
```

2. Run the updated script (v2.4)

3. Verify configuration before starting

4. Start VM and check serial console:
```bash
qm start {vm_id}
qm terminal {vm_id}
```

The VM should now boot successfully! 🚀
