# Quick Start Guide - Proxmox VM Deployment

## Overview
This script automates Proxmox VM deployment with custom OVMF firmware. It only requires **3 files** and builds the VM configuration interactively.

## Required Files (3 Total)
1. `*.qcow2` - Your VM disk image
2. `OVMF_CODE*.fd` - OVMF CODE firmware file
3. `OVMF_VARS*.fd` - OVMF VARS firmware file

## Quick Start

### 1. Upload Files to Proxmox Host
```bash
scp disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd proxmox_vm_deploy.py root@your-proxmox:/root/
```

### 2. Run the Script
```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd
```

### 3. Answer the Prompts

**Required (must specify):**
- VM Name: `my-ubuntu-vm`
- VM ID: `100`
- Storage: `local-lvm`

**Optional (press Enter for defaults):**
- RAM: `[4096]` MB
- CPU Cores: `[2]`
- CPU Sockets: `[1]`
- CPU Type: `[host]`
- OS Type: `[l26]` (Linux)
- SCSI Controller: `[virtio-scsi-pci]`
- Network Bridge: `[vmbr0]`
- Guest Agent: `[yes]`
- Machine Type: `[q35]`

### 4. Confirm Deployment
Review the configuration summary and type `yes` to proceed.

### 5. Start and Access Your VM
```bash
# Start the VM (disk already attached and boot configured!)
sudo qm start 100

# Check status
sudo qm status 100

# Access serial console
sudo qm terminal 100
```

## What Happens During Deployment

1. ✅ Validates all 3 files exist
2. ✅ Detects Proxmox node name
3. ✅ Prompts for configuration
4. ✅ Saves config to `/tmp/vm_{id}_config.json`
5. ✅ Creates VM with `qm create` (including serial console)
6. ✅ Imports disk with `qm importdisk`
7. ✅ Attaches disk to virtio0 with iothread automatically
8. ✅ Sets boot order to virtio0 automatically
9. ✅ Copies OVMF files to `/usr/share/OVMF/`
10. ✅ Adds OVMF args to VM config file

## Common Storage Names

- `local-lvm` - Default LVM storage
- `local` - Local directory storage
- `local-zfs` - ZFS storage
- Custom storage pools you've created

To list available storage:
```bash
pvesm status
```

## Common Issues

### "Permission denied"
→ Run with `sudo`

### "VM already exists"
→ Choose different VM ID or delete existing: `qm destroy <id>`

### "Storage not found"
→ Check storage name: `pvesm status`

### "Can't access console"
→ Use serial console: `qm terminal <id>` (exit with Ctrl+O)

## Complete Example

```bash
# Upload to Proxmox
scp ubuntu.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd proxmox_vm_deploy.py root@192.168.1.10:/root/

# SSH to Proxmox
ssh root@192.168.1.10

# Run deployment
sudo python3 proxmox_vm_deploy.py ubuntu.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd

# Answer prompts:
# VM name: ubuntu-web
# VM ID: 100
# Storage: local-lvm
# (Press Enter for all other defaults)
# Confirm: yes

# After completion, just start the VM!
sudo qm start 100

# Access serial console
sudo qm terminal 100
```

## Tips

- **Use descriptive names**: `prod-web-01`, `dev-db-02`
- **Organize IDs**: 100-199 for web, 200-299 for databases
- **Accept defaults**: Just press Enter for standard configs
- **Check first**: Review config summary before confirming

## Need Help?

See the full README.md for:
- Detailed troubleshooting
- Advanced configuration options
- Multiple VM deployment strategies
- Network and storage customization

---

**That's it!** The script handles everything else automatically.
