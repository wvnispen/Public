# Script Banner - Visual Preview

## What You'll See When Running the Script

When you run the deployment script, you'll see this banner at the top:

```
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║          SonicWall NSx Deployment Script for Proxmox                    ║
║                                                                          ║
║          Created by Wynand van Nispen (wvannipen@sonicwall.com)        ║
║          Version: 2.5 (Current Version)                                 ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝

============================================================
Proxmox VM Deployment Script with OVMF Support
============================================================
✓ Found QCOW2 disk image: disk.qcow2
✓ Found OVMF_CODE file: OVMF_CODE.sw.fd
✓ Found OVMF_VARS file: OVMF_VARS.sw.fd

✓ Proxmox node: pve

============================================================
Proxmox VM Deployment - Configuration
============================================================

Enter VM name: 
```

## Banner Features

- **Professional Design**: Clean box-drawing characters (Unicode)
- **Company Branding**: SonicWall NSx clearly displayed
- **Attribution**: Your name and email
- **Version Info**: Shows current version (2.5)
- **Centered Layout**: All text properly aligned

## Banner Specifications

- Width: 74 characters
- Height: 7 lines
- Character Set: Unicode box-drawing characters
  - `╔` `═` `╗` - Top corners and border
  - `║` - Side borders
  - `╚` `═` `╝` - Bottom corners and border

## Customization

To change the banner, edit the `display_banner()` method in the script:

```python
def display_banner(self):
    """Display startup banner."""
    banner = """
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║          SonicWall NSx Deployment Script for Proxmox                    ║
║                                                                          ║
║          Created by Wynand van Nispen (wvannipen@sonicwall.com)        ║
║          Version: 2.5 (Current Version)                                 ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)
```

### Change Version Number

Update the version line:
```python
║          Version: 3.0 (Current Version)                                 ║
```

### Change Title

Update the title line:
```python
║          SonicWall NSx Automated Deployment for Proxmox                 ║
```

### Add Additional Info

Add more lines within the banner:
```python
║          Support: support@sonicwall.com                                 ║
```

## Terminal Compatibility

The banner uses Unicode box-drawing characters (U+2500 block) which are supported by:
- ✅ Modern Linux terminals (bash, zsh)
- ✅ Windows Terminal
- ✅ macOS Terminal
- ✅ PuTTY (with proper encoding)
- ✅ SSH clients with UTF-8 support

If characters don't display correctly, ensure your terminal is set to UTF-8 encoding.

## Example Output Sessions

### Successful Deployment
```
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║          SonicWall NSx Deployment Script for Proxmox                    ║
║                                                                          ║
║          Created by Wynand van Nispen (wvannipen@sonicwall.com)        ║
║          Version: 2.5 (Current Version)                                 ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝

============================================================
Proxmox VM Deployment Script with OVMF Support
============================================================
✓ Found QCOW2 disk image: NSx270.qcow2
✓ Found OVMF_CODE file: OVMF_CODE.sw.fd
✓ Found OVMF_VARS file: OVMF_VARS.sw.fd

✓ Proxmox node: pve

============================================================
Proxmox VM Deployment - Configuration
============================================================

Enter VM name: nsx-fw-01
Enter VM ID (e.g., 100): 100
Enter storage name (e.g., local-lvm): local-lvm

------------------------------------------------------------
Advanced VM Configuration
------------------------------------------------------------
Enter RAM in MB [4096]: 8192
Enter number of CPU cores [2]: 4
...
```

### Version Information

The banner displays:
- **Script Name**: SonicWall NSx Deployment Script for Proxmox
- **Purpose**: Clear identification as a SonicWall product deployment tool
- **Creator**: Your name and email for support/questions
- **Version**: 2.5 (updated with each major change)

## Professional Look

The banner gives the script a professional, polished appearance suitable for:
- Enterprise environments
- Production deployments
- Client-facing deployments
- Internal IT operations
- Training and demonstrations

## Script Identity

The banner clearly identifies:
1. What the script does (SonicWall NSx Deployment)
2. Target platform (Proxmox)
3. Who created it (Wynand van Nispen)
4. How to contact for support (wvannipen@sonicwall.com)
5. Current version (2.5)

This helps with:
- Script identification in logs
- Support requests
- Version tracking
- Professional presentation

---

**Banner Status**: ✅ Implemented in v2.5  
**Location**: Displays at script startup  
**Customizable**: Yes, via `display_banner()` method
