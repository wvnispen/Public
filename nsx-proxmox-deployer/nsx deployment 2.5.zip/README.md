# Proxmox VM Deployment Script with OVMF Support

A Python script to automate the deployment of Proxmox VMs with custom OVMF firmware files. The script generates the VM configuration through interactive prompts.

## Features

- ✅ Automated VM creation with interactive configuration
- ✅ QCOW2 disk image import
- ✅ **Automatic disk attachment to SCSI0**
- ✅ **Automatic boot order configuration**
- ✅ **Serial console adapter configured**
- ✅ Custom OVMF firmware installation
- ✅ Automatic VM configuration with OVMF args
- ✅ Interactive prompts for all VM parameters
- ✅ Configuration saved to JSON file for reference
- ✅ Comprehensive error handling and validation

## Requirements

- Proxmox VE (tested on 7.x and 8.x)
- Python 3.6 or higher
- Root/sudo access
- Required files (3 files total):
  1. QCOW2 disk image (*.qcow2)
  2. OVMF_CODE firmware file (*.fd)
  3. OVMF_VARS firmware file (*.fd)

## Installation

1. Copy the script to your Proxmox host:
   ```bash
   scp proxmox_vm_deploy.py root@proxmox-host:/root/
   ```

2. Make the script executable:
   ```bash
   chmod +x proxmox_vm_deploy.py
   ```

## Usage

### Basic Usage

```bash
sudo python3 proxmox_vm_deploy.py <qcow2_file> <ovmf_code_file> <ovmf_vars_file>
```

### Example

```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd
```

### Interactive Prompts

The script will prompt you for the following configuration:

#### Required Parameters:
1. **VM Name**: A descriptive name for your VM
2. **VM ID**: A unique numeric identifier (e.g., 100, 101, 102)
3. **Storage Name**: The Proxmox storage to use (e.g., local-lvm, local, ceph-storage)

#### Advanced Configuration (with defaults):
4. **RAM (Memory)**: Amount of RAM in MB [default: 4096]
5. **CPU Cores**: Number of CPU cores [default: 2]
6. **CPU Sockets**: Number of CPU sockets [default: 1]
7. **CPU Type**: CPU type (host/x86-64-v2-AES/kvm64) [default: host]
8. **OS Type**: Operating system type [default: l26 (Linux)]
9. **SCSI Controller**: SCSI hardware controller [default: virtio-scsi-pci]
10. **Network Bridge**: Network bridge to use [default: vmbr0]
11. **QEMU Guest Agent**: Enable guest agent (yes/no) [default: yes]
12. **Machine Type**: Machine type (q35/pc) [default: q35]

Press Enter to accept default values or type your custom value.

## Example Session

```bash
$ sudo python3 proxmox_vm_deploy.py ubuntu-22.04.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd

============================================================
Proxmox VM Deployment Script with OVMF Support
============================================================
✓ Found QCOW2 disk image: ubuntu-22.04.qcow2
✓ Found OVMF_CODE file: OVMF_CODE.sw.fd
✓ Found OVMF_VARS file: OVMF_VARS.sw.fd

✓ Proxmox node: pve

============================================================
Proxmox VM Deployment - Configuration
============================================================

Enter VM name: Ubuntu-WebServer
Enter VM ID (e.g., 100): 100
Enter storage name (e.g., local-lvm): local-lvm

------------------------------------------------------------
Advanced VM Configuration
------------------------------------------------------------
Enter RAM in MB [4096]: 8192
Enter number of CPU cores [2]: 4
Enter number of CPU sockets [1]: 
Enter CPU type (host/x86-64-v2-AES/kvm64) [host]: 

OS Types: l26 (Linux 2.6+), win11 (Windows 11), win10 (Windows 10), other
Enter OS type [l26]: 
Enter SCSI controller (virtio-scsi-pci/virtio-scsi-single) [virtio-scsi-pci]: 
Enter network bridge [vmbr0]: 
Enable QEMU guest agent? (yes/no) [yes]: 
Enter machine type (q35/pc) [q35]: 

============================================================
Configuration Summary:
============================================================
VM Name:        Ubuntu-WebServer
VM ID:          100
Storage:        local-lvm
Memory:         8192 MB
CPU:            4 cores, 1 socket(s), type: host
OS Type:        l26
SCSI HW:        virtio-scsi-pci
Network:        vmbr0
Guest Agent:    Enabled
Machine:        q35
BIOS:           OVMF (UEFI)
============================================================

💾 Configuration saved to: /tmp/vm_100_config.json

Proceed with deployment? (yes/no): yes
```

## What the Script Does

1. **Validates Files**: Checks that all 3 required files exist
2. **Gets Node Name**: Automatically detects Proxmox node name
3. **Prompts User**: Interactive prompts for VM configuration
4. **Saves Configuration**: Creates JSON file in /tmp for reference
5. **Creates VM**: Uses `qm create` with specified parameters (including serial adapter)
6. **Imports Disk**: Uses `qm importdisk` to import the QCOW2 image
7. **Attaches Disk**: Automatically attaches disk to virtio0 with iothread enabled
8. **Sets Boot Order**: Configures VM to boot from virtio0
9. **Copies OVMF Files**: Copies firmware files to `/usr/share/OVMF/`
10. **Updates Config**: Adds OVMF args to the VM's `.conf` file

## Generated Configuration

The script automatically generates a VM configuration and saves it to `/tmp/vm_{vm_id}_config.json` for your reference.

Example generated configuration:
```json
{
  "bios": "seabios",
  "cores": 2,
  "cpu": "x86-64-v2-AES",
  "efidisk0": "local-lvm:0,efitype=4m,pre-enrolled-keys=1,size=1M",
  "ide2": "none,media=cdrom",
  "machine": "q35",
  "memory": 4096,
  "name": "my-vm",
  "net0": "virtio,bridge=vmbr0",
  "numa": "0",
  "ostype": "l26",
  "scsihw": "virtio-scsi-single",
  "serial0": "socket",
  "sockets": 1,
  "agent": "1"
}
```

Note: The actual VM config file will also include:
- `args:` line with OVMF firmware paths (added at top): `/usr/share/pve-edk2-firmware/{vm_id}/`
- `boot: order=virtio0` (set during disk attachment)
- `virtio0:` disk configuration (set during disk attachment)
- `meta:` and `vmgenid:` (auto-generated by Proxmox)

## OS Types

Common OS types you can use:

| OS Type | Description |
|---------|-------------|
| `l26` | Linux 2.6+ kernel (default) |
| `l24` | Linux 2.4 kernel |
| `win11` | Windows 11 |
| `win10` | Windows 10 |
| `win8` | Windows 8/2012 |
| `win7` | Windows 7/2008 |
| `other` | Other/Unknown OS |

## CPU Types

| CPU Type | Description |
|----------|-------------|
| `host` | Host CPU (best performance, recommended) |
| `x86-64-v2-AES` | Generic x86-64 v2 with AES |
| `kvm64` | KVM default (maximum compatibility) |
| `Cascadelake-Server` | Intel Cascadelake |
| `EPYC` | AMD EPYC |

## OVMF Configuration

The script automatically adds the following line to the top of your VM's configuration file:

```
args: -drive 'if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_CODE.sw.fd' -drive 'if=pflash,unit=1,format=raw,file=/usr/share/pve-edk2-firmware/{vm_id}/OVMF_VARS.sw.fd'
```

This configures the VM to use custom OVMF firmware files for UEFI boot. Each VM gets its own isolated OVMF firmware directory based on its VM ID.

## Serial Console Configuration

The script automatically configures a serial console adapter for your VM:

```
serial0: socket
```

This provides:
- Direct serial console access via `qm terminal <vm_id>`
- Better compatibility with headless systems
- Useful for troubleshooting boot issues
- Access to GRUB and bootloader output

To access the serial console:
```bash
qm terminal <vm_id>
```

To exit the serial console, press `Ctrl+O`

## OVMF Firmware Isolation

Each VM gets its own OVMF firmware directory:
```
/usr/share/pve-edk2-firmware/
├── 100/
│   ├── OVMF_CODE.sw.fd
│   └── OVMF_VARS.sw.fd
├── 101/
│   ├── OVMF_CODE.sw.fd
│   └── OVMF_VARS.sw.fd
└── ...
```

This ensures:
- Each VM has isolated NVRAM variables
- UEFI settings don't interfere between VMs
- Easier management and troubleshooting
- Follows Proxmox best practices

## File Locations

- **OVMF Files**: Copied to `/usr/share/pve-edk2-firmware/{vm_id}/`
  - `OVMF_CODE.sw.fd`
  - `OVMF_VARS.sw.fd`
  - Each VM gets its own subdirectory
- **VM Config**: `/etc/pve/nodes/{node_name}/qemu-server/{vm_id}.conf`
- **Saved JSON Config**: `/tmp/vm_{vm_id}_config.json`

## Post-Deployment Steps

After successful deployment, your VM is ready to use! The script has already:
- ✅ Attached the disk to virtio0 with iothread enabled
- ✅ Set boot order to virtio0
- ✅ Configured serial console access
- ✅ Added OVMF firmware configuration

### Start the VM
```bash
qm start <vm_id>
```

Example:
```bash
qm start 100
```

### Access Serial Console
```bash
qm terminal <vm_id>
```

Example:
```bash
qm terminal 100
```

### View VM Status
```bash
qm status <vm_id>
```

### View VM Configuration
```bash
qm config <vm_id>
```

Or use the Proxmox web interface.

## Troubleshooting

### Permission Denied Errors

Make sure to run the script with `sudo` or as root:
```bash
sudo python3 proxmox_vm_deploy.py ...
```

### VM Already Exists

If a VM with the specified ID already exists, you'll get an error. Either:
- Choose a different VM ID
- Delete the existing VM: `qm destroy <vm_id>`

### Disk Import Fails

Ensure the storage name is correct and the storage has enough space:
```bash
pvesm status
```

To list available storage:
```bash
pvesm list
```

### OVMF Boot Issues

If the VM doesn't boot correctly:
1. Check the VM's boot order: `qm config <vm_id>`
2. Verify the efidisk0 configuration
3. Ensure the QCOW2 image is UEFI-compatible
4. Check the VM's display settings (try different display types)

### Checking VM Configuration

View the generated configuration:
```bash
cat /etc/pve/nodes/{node_name}/qemu-server/{vm_id}.conf
```

View the saved JSON config:
```bash
cat /tmp/vm_{vm_id}_config.json
```

### Common Issues and Solutions

**Issue**: Imported disk not showing up
```bash
# List imported disks
qm disk list <vm_id>

# Manually attach disk
qm set <vm_id> --virtio0 <storage>:vm-<vm_id>-disk-0,iothread=1
```

**Issue**: VM won't start
```bash
# Check VM configuration
qm config <vm_id>

# Check system logs
journalctl -u pve-cluster
```

**Issue**: Network not working
```bash
# Check network configuration
qm config <vm_id> | grep net

# Update network settings
qm set <vm_id> --net0 virtio,bridge=vmbr0
```

## Advanced Usage

### Quick Deployment with Defaults

To quickly deploy with all default settings, just press Enter for all prompts except VM name, ID, and storage.

### Customizing Network Settings

To use a different bridge or add VLANs:
```bash
# When prompted for network bridge, specify with VLAN:
# Enter network bridge [vmbr0]: vmbr0,tag=100
```

### Multiple Network Interfaces

After deployment, add additional network interfaces:
```bash
qm set <vm_id> --net1 virtio,bridge=vmbr1
```

### Resizing Disk After Import

```bash
qm resize <vm_id> virtio0 +50G
```

## Complete Workflow Example

```bash
# 1. Prepare your files in a directory
mkdir vm-deployment
cd vm-deployment
cp /path/to/ubuntu-22.04.qcow2 .
cp /path/to/OVMF_CODE.sw.fd .
cp /path/to/OVMF_VARS.sw.fd .

# 2. Run the deployment script
sudo python3 proxmox_vm_deploy.py \
    ubuntu-22.04.qcow2 \
    OVMF_CODE.sw.fd \
    OVMF_VARS.sw.fd

# 3. Follow the prompts
# VM name: web-server-01
# VM ID: 100
# Storage: local-lvm
# (accept defaults for other settings or customize)

# 4. Start the VM (disk is already attached and boot configured!)
sudo qm start 100

# 5. Monitor the VM
sudo qm status 100

# 6. Access serial console
sudo qm terminal 100
```

## Automation with Defaults

If you want to automate deployment with default values, you can use here-documents:

```bash
sudo python3 proxmox_vm_deploy.py disk.qcow2 OVMF_CODE.sw.fd OVMF_VARS.sw.fd <<EOF
MyVM
100
local-lvm








yes

EOF
```

## Security Notes

- This script requires root privileges to:
  - Create VMs
  - Copy files to `/usr/share/OVMF/`
  - Modify files in `/etc/pve/`
- Always verify the source of OVMF firmware files
- Review the configuration before confirming deployment
- The configuration file is saved to `/tmp` and readable by all users

## Tips

1. **Test First**: Test deployments with a small disk image first
2. **Name Convention**: Use descriptive VM names (e.g., `prod-web-01`, `dev-db-02`)
3. **ID Ranges**: Use ID ranges to organize VMs (100-199 for web servers, 200-299 for databases, etc.)
4. **Storage Selection**: Choose appropriate storage based on performance needs (SSD vs HDD)
5. **Resource Planning**: Don't over-allocate CPU cores (leave some for the host)

## License

This script is provided as-is for use with Proxmox VE.

## Support

For Proxmox-specific issues, consult:
- [Proxmox VE Documentation](https://pve.proxmox.com/wiki/Main_Page)
- [Proxmox Forums](https://forum.proxmox.com/)

## Version History

- **v2.0**: Updated to use interactive configuration builder (no JSON file required)
- **v1.0**: Initial release with JSON configuration file
